import os
from dataclasses import dataclass, field


@dataclass
class Settings:
    database_url: str = field(
        default_factory=lambda: os.getenv("DATABASE_URL", "sqlite:///./spendwise.db")
    )
    secret_key: str = field(
        default_factory=lambda: os.getenv("SECRET_KEY", "dev-only-change-me")
    )
    algorithm: str = "HS256"
    access_token_expire_minutes: int = field(
        default_factory=lambda: int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))
    )
    # OWASP recommends >= 600k for PBKDF2-HMAC-SHA256. Tests lower this for speed.
    pbkdf2_iterations: int = field(
        default_factory=lambda: int(os.getenv("PBKDF2_ITERATIONS", "600000"))
    )


settings = Settings()
