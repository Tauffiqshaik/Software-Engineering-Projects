from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Annotated, Generic, Literal, TypeVar

from fastapi import Query
from pydantic import (
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
    StringConstraints,
    field_validator,
)

from .models import TransactionType

T = TypeVar("T")

# Positive money with at most 2 decimal places (10.999 is rejected, not silently rounded).
Money = Annotated[Decimal, Field(gt=0, max_digits=12, decimal_places=2)]
Month = Annotated[str, Field(pattern=r"^\d{4}-(0[1-9]|1[0-2])$", examples=["2026-10"])]
# For query-string use: Query(...) would otherwise discard a pattern set via Field.
MonthParam = Annotated[str, Query(pattern=r"^\d{4}-(0[1-9]|1[0-2])$", description="YYYY-MM", examples=["2026-10"])]
Name = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=50)]
Keyword = Annotated[
    str, StringConstraints(strip_whitespace=True, to_lower=True, min_length=1, max_length=50)
]


# ---------- auth ----------
class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    email: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---------- categories ----------
class CategoryCreate(BaseModel):
    name: Name
    keywords: list[Keyword] = Field(default_factory=list, max_length=50)


class CategoryUpdate(BaseModel):
    name: Name | None = None
    keywords: list[Keyword] | None = Field(default=None, max_length=50)


class CategoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    keywords: list[str]


# ---------- transactions ----------
class TransactionCreate(BaseModel):
    amount: Money
    type: TransactionType
    description: Annotated[str, StringConstraints(strip_whitespace=True, max_length=255)] = ""
    occurred_on: date
    category_id: int | None = None

    @field_validator("occurred_on")
    @classmethod
    def _sane_date(cls, v: date) -> date:
        if v < date(1970, 1, 1):
            raise ValueError("date is too far in the past")
        if v > date.today() + timedelta(days=1):
            raise ValueError("date cannot be in the future")
        return v


class TransactionUpdate(BaseModel):
    amount: Money | None = None
    type: TransactionType | None = None
    description: Annotated[str, StringConstraints(strip_whitespace=True, max_length=255)] | None = None
    occurred_on: date | None = None
    category_id: int | None = None

    @field_validator("occurred_on")
    @classmethod
    def _sane_date(cls, v: date | None) -> date | None:
        if v is None:
            return v
        return TransactionCreate._sane_date(v)  # reuse the same rule


class TransactionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    amount: Decimal
    type: TransactionType
    description: str
    occurred_on: date
    category_id: int | None
    created_at: datetime


class BulkTransactionCreate(BaseModel):
    items: list[TransactionCreate] = Field(min_length=1, max_length=100)


class Page(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    page_size: int
    pages: int


# ---------- budgets ----------
class BudgetCreate(BaseModel):
    category_id: int
    month: Month
    limit_amount: Money


class BudgetUpdate(BaseModel):
    limit_amount: Money


class BudgetOut(BaseModel):
    id: int
    category_id: int
    month: str
    limit_amount: Decimal


class BudgetStatus(BudgetOut):
    category_name: str
    spent: Decimal
    remaining: Decimal
    percent_used: float
    status: Literal["ok", "warning", "exceeded"]


# ---------- reports ----------
class CategoryTotal(BaseModel):
    category_id: int | None
    category_name: str
    total: Decimal
    count: int


class MonthlyReport(BaseModel):
    month: str
    total_income: Decimal
    total_expense: Decimal
    net: Decimal
    transaction_count: int
    expenses_by_category: list[CategoryTotal]
    income_by_category: list[CategoryTotal]
    budgets: list[BudgetStatus]


class TrendPoint(BaseModel):
    month: str
    income: Decimal
    expense: Decimal
    net: Decimal
