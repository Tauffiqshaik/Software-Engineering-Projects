import csv
import hashlib
import io
import json
import math
from datetime import date
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Response, status
from sqlalchemy import asc, desc, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Category, IdempotencyKey, Transaction, TransactionType, User
from ..schemas import (
    BulkTransactionCreate,
    Page,
    TransactionCreate,
    TransactionOut,
    TransactionUpdate,
)
from ..security import get_current_user
from ..services import auto_categorize, get_owned_category

router = APIRouter(prefix="/transactions", tags=["transactions"])

SORTABLE = {
    "occurred_on": Transaction.occurred_on,
    "amount": Transaction.amount,
    "created_at": Transaction.created_at,
    "id": Transaction.id,
}
MAX_EXPORT_ROWS = 100_000


class TxFilters:
    """Query-string filters shared by the list and export endpoints."""

    def __init__(
        self,
        type: TransactionType | None = None,
        category_id: int | None = None,
        date_from: date | None = None,
        date_to: date | None = None,
        min_amount: Decimal | None = Query(None, ge=0),
        max_amount: Decimal | None = Query(None, ge=0),
        q: str | None = Query(None, max_length=100, description="Search in description"),
    ):
        if date_from and date_to and date_from > date_to:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "date_from must be <= date_to")
        if min_amount is not None and max_amount is not None and min_amount > max_amount:
            raise HTTPException(
                status.HTTP_422_UNPROCESSABLE_ENTITY, "min_amount must be <= max_amount"
            )
        self.type, self.category_id = type, category_id
        self.date_from, self.date_to = date_from, date_to
        self.min_amount, self.max_amount, self.q = min_amount, max_amount, q

    def conditions(self, user_id: int) -> list:
        conds = [Transaction.user_id == user_id]
        if self.type:
            conds.append(Transaction.type == self.type)
        if self.category_id is not None:
            conds.append(Transaction.category_id == self.category_id)
        if self.date_from:
            conds.append(Transaction.occurred_on >= self.date_from)
        if self.date_to:
            conds.append(Transaction.occurred_on <= self.date_to)
        if self.min_amount is not None:
            conds.append(Transaction.amount >= self.min_amount)
        if self.max_amount is not None:
            conds.append(Transaction.amount <= self.max_amount)
        if self.q:
            escaped = self.q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            conds.append(Transaction.description.ilike(f"%{escaped}%", escape="\\"))
        return conds


def _ordering(sort_by: str, order: str):
    col = SORTABLE[sort_by]
    # id as tiebreaker keeps pagination stable when many rows share a sort value.
    return [asc(col) if order == "asc" else desc(col), asc(Transaction.id)]


def _resolve_category(db: Session, user_id: int, category_id: int | None, description: str) -> int | None:
    if category_id is not None:
        return get_owned_category(db, user_id, category_id).id
    return auto_categorize(db, user_id, description)


# ---------------------------------------------------------------- create
def _request_hash(payload: TransactionCreate) -> str:
    body = json.dumps(payload.model_dump(mode="json"), sort_keys=True)
    return hashlib.sha256(body.encode()).hexdigest()


def _find_key(db: Session, user_id: int, key: str) -> IdempotencyKey | None:
    return db.scalar(
        select(IdempotencyKey).where(IdempotencyKey.user_id == user_id, IdempotencyKey.key == key)
    )


def _replay(existing: IdempotencyKey, request_hash: str, response: Response) -> dict:
    if existing.request_hash != request_hash:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "Idempotency-Key was already used with a different request body",
        )
    response.headers["Idempotent-Replay"] = "true"
    return existing.response_body


@router.post("", response_model=TransactionOut, status_code=status.HTTP_201_CREATED)
def create_transaction(
    payload: TransactionCreate,
    response: Response,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key", max_length=255),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Create a transaction.

    Send an `Idempotency-Key` header to make retries safe: the same key + same body
    returns the original response instead of creating a duplicate.
    """
    req_hash = _request_hash(payload) if idempotency_key else ""
    if idempotency_key:
        existing = _find_key(db, user.id, idempotency_key)
        if existing:
            return _replay(existing, req_hash, response)

    category_id = _resolve_category(db, user.id, payload.category_id, payload.description)
    tx = Transaction(user_id=user.id, category_id=category_id, **payload.model_dump(exclude={"category_id"}))
    db.add(tx)
    db.flush()  # assigns tx.id inside the open DB transaction

    if idempotency_key:
        body = TransactionOut.model_validate(tx).model_dump(mode="json")
        db.add(
            IdempotencyKey(
                user_id=user.id, key=idempotency_key, request_hash=req_hash, response_body=body
            )
        )
    try:
        db.commit()  # transaction row + idempotency record commit atomically
    except IntegrityError:
        # Lost a race against a concurrent request with the same key: replay the winner.
        db.rollback()
        existing = _find_key(db, user.id, idempotency_key) if idempotency_key else None
        if existing is None:
            raise
        return _replay(existing, req_hash, response)
    return tx


@router.post("/bulk", response_model=list[TransactionOut], status_code=status.HTTP_201_CREATED)
def bulk_create(
    payload: BulkTransactionCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """All-or-nothing import: if any item is invalid, nothing is saved."""
    wanted = {i.category_id for i in payload.items if i.category_id is not None}
    if wanted:
        found = set(
            db.scalars(
                select(Category.id).where(Category.user_id == user.id, Category.id.in_(wanted))
            )
        )
        missing = sorted(wanted - found)
        if missing:
            raise HTTPException(status.HTTP_404_NOT_FOUND, f"Unknown category ids: {missing}")

    created: list[Transaction] = []
    try:
        for item in payload.items:
            cat_id = item.category_id or auto_categorize(db, user.id, item.description)
            tx = Transaction(user_id=user.id, category_id=cat_id, **item.model_dump(exclude={"category_id"}))
            db.add(tx)
            created.append(tx)
        db.commit()
    except Exception:
        db.rollback()
        raise
    return created


# ------------------------------------------------------------------ read
@router.get("", response_model=Page[TransactionOut])
def list_transactions(
    filters: TxFilters = Depends(),
    sort_by: Literal["occurred_on", "amount", "created_at", "id"] = "occurred_on",
    order: Literal["asc", "desc"] = "desc",
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    conds = filters.conditions(user.id)
    total = db.scalar(select(func.count()).select_from(Transaction).where(*conds)) or 0
    items = db.scalars(
        select(Transaction)
        .where(*conds)
        .order_by(*_ordering(sort_by, order))
        .limit(page_size)
        .offset((page - 1) * page_size)
    ).all()
    return Page(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        pages=math.ceil(total / page_size) if total else 0,
    )


def _csv_safe(value: str) -> str:
    """Neutralise spreadsheet formula injection (=, +, -, @ at the start of a cell)."""
    return "'" + value if value[:1] in ("=", "+", "-", "@", "\t", "\r") else value


@router.get("/export")
def export_transactions(
    filters: TxFilters = Depends(),
    sort_by: Literal["occurred_on", "amount", "created_at", "id"] = "occurred_on",
    order: Literal["asc", "desc"] = "desc",
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Download the (filtered) transactions as CSV."""
    rows = db.execute(
        select(Transaction, Category.name)
        .outerjoin(Category, Category.id == Transaction.category_id)
        .where(*filters.conditions(user.id))
        .order_by(*_ordering(sort_by, order))
        .limit(MAX_EXPORT_ROWS)
    ).all()

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["id", "date", "type", "amount", "category", "description"])
    for tx, cat_name in rows:
        writer.writerow(
            [
                tx.id,
                tx.occurred_on.isoformat(),
                tx.type.value,
                f"{tx.amount:.2f}",
                _csv_safe(cat_name or ""),
                _csv_safe(tx.description or ""),
            ]
        )
    return Response(
        content=buf.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": 'attachment; filename="transactions.csv"'},
    )


def _get_owned(db: Session, user_id: int, tx_id: int) -> Transaction:
    tx = db.get(Transaction, tx_id)
    if tx is None or tx.user_id != user_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Transaction not found")
    return tx


@router.get("/{transaction_id}", response_model=TransactionOut)
def get_transaction(
    transaction_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    return _get_owned(db, user.id, transaction_id)


@router.patch("/{transaction_id}", response_model=TransactionOut)
def update_transaction(
    transaction_id: int,
    payload: TransactionUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    tx = _get_owned(db, user.id, transaction_id)
    data = payload.model_dump(exclude_unset=True)
    if not data:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "No fields to update")
    for required in ("amount", "type", "occurred_on", "description"):
        if required in data and data[required] is None:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, f"{required} cannot be null")
    if data.get("category_id") is not None:
        get_owned_category(db, user.id, data["category_id"])
    for field, value in data.items():
        setattr(tx, field, value)
    db.commit()
    return tx


@router.delete("/{transaction_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_transaction(
    transaction_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    db.delete(_get_owned(db, user.id, transaction_id))
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
