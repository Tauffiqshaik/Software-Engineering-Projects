from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Budget, Category, User
from ..schemas import BudgetCreate, BudgetOut, BudgetStatus, BudgetUpdate, MonthParam
from ..security import get_current_user
from ..services import (
    budget_out,
    budget_status,
    get_owned_category,
    month_bounds,
    month_start,
    spent_by_category,
)

router = APIRouter(prefix="/budgets", tags=["budgets"])

ZERO = Decimal("0.00")


def _conflict() -> HTTPException:
    return HTTPException(status.HTTP_409_CONFLICT, "A budget for this category and month already exists")


@router.post("", response_model=BudgetOut, status_code=status.HTTP_201_CREATED)
def create_budget(
    payload: BudgetCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    get_owned_category(db, user.id, payload.category_id)
    month = month_start(payload.month)
    exists = db.scalar(
        select(Budget.id).where(
            Budget.user_id == user.id, Budget.category_id == payload.category_id, Budget.month == month
        )
    )
    if exists:
        raise _conflict()
    budget = Budget(
        user_id=user.id,
        category_id=payload.category_id,
        month=month,
        limit_amount=payload.limit_amount,
    )
    db.add(budget)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise _conflict()
    return budget_out(budget)


@router.get("", response_model=list[BudgetOut])
def list_budgets(
    month: MonthParam | None = None,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    stmt = select(Budget).where(Budget.user_id == user.id).order_by(Budget.month.desc(), Budget.id)
    if month:
        stmt = stmt.where(Budget.month == month_start(month))
    return [budget_out(b) for b in db.scalars(stmt)]


@router.get("/status", response_model=list[BudgetStatus])
def budget_statuses(
    month: MonthParam,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Spent vs. limit for every budget in a month."""
    start, end = month_bounds(month)
    spent = spent_by_category(db, user.id, start, end)
    rows = db.execute(
        select(Budget, Category.name)
        .join(Category, Category.id == Budget.category_id)
        .where(Budget.user_id == user.id, Budget.month == start)
        .order_by(Category.name)
    ).all()
    return [budget_status(b, name, spent.get(b.category_id, ZERO)) for b, name in rows]


@router.patch("/{budget_id}", response_model=BudgetOut)
def update_budget(
    budget_id: int,
    payload: BudgetUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    budget = db.get(Budget, budget_id)
    if budget is None or budget.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Budget not found")
    budget.limit_amount = payload.limit_amount
    db.commit()
    return budget_out(budget)


@router.delete("/{budget_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_budget(budget_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    budget = db.get(Budget, budget_id)
    if budget is None or budget.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Budget not found")
    db.delete(budget)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
