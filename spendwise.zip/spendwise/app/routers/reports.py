from decimal import Decimal

from fastapi import APIRouter, Depends, Query
from sqlalchemy import extract, func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Budget, Category, Transaction, TransactionType, User
from ..schemas import CategoryTotal, MonthParam, MonthlyReport, TrendPoint
from ..security import get_current_user
from ..services import (
    budget_status,
    month_bounds,
    month_label,
    month_start,
    next_month,
    q2,
    spent_by_category,
)

router = APIRouter(prefix="/reports", tags=["reports"])

ZERO = Decimal("0.00")


def _totals_by_category(db: Session, user_id: int, start, end, tx_type: TransactionType):
    rows = db.execute(
        select(
            Transaction.category_id,
            Category.name,
            func.sum(Transaction.amount),
            func.count(Transaction.id),
        )
        .outerjoin(Category, Category.id == Transaction.category_id)
        .where(
            Transaction.user_id == user_id,
            Transaction.type == tx_type,
            Transaction.occurred_on >= start,
            Transaction.occurred_on < end,
        )
        .group_by(Transaction.category_id, Category.name)
    ).all()
    result = [
        CategoryTotal(
            category_id=cat_id, category_name=name or "Uncategorized", total=q2(total), count=count
        )
        for cat_id, name, total, count in rows
    ]
    return sorted(result, key=lambda r: r.total, reverse=True)


@router.get("/monthly", response_model=MonthlyReport)
def monthly_report(
    month: MonthParam,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    start, end = month_bounds(month)
    expenses = _totals_by_category(db, user.id, start, end, TransactionType.expense)
    income = _totals_by_category(db, user.id, start, end, TransactionType.income)
    total_expense = sum((r.total for r in expenses), ZERO)
    total_income = sum((r.total for r in income), ZERO)

    spent = spent_by_category(db, user.id, start, end)
    budget_rows = db.execute(
        select(Budget, Category.name)
        .join(Category, Category.id == Budget.category_id)
        .where(Budget.user_id == user.id, Budget.month == start)
        .order_by(Category.name)
    ).all()

    return MonthlyReport(
        month=month,
        total_income=total_income,
        total_expense=total_expense,
        net=total_income - total_expense,
        transaction_count=sum(r.count for r in expenses) + sum(r.count for r in income),
        expenses_by_category=expenses,
        income_by_category=income,
        budgets=[budget_status(b, name, spent.get(b.category_id, ZERO)) for b, name in budget_rows],
    )


@router.get("/trend", response_model=list[TrendPoint])
def spending_trend(
    end_month: MonthParam,
    months: int = Query(6, ge=1, le=24),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Income / expense / net per month for the `months` months ending at `end_month`."""
    last = month_start(end_month)
    first = last
    for _ in range(months - 1):
        first = (
            first.replace(year=first.year - 1, month=12)
            if first.month == 1
            else first.replace(month=first.month - 1)
        )

    rows = db.execute(
        select(
            extract("year", Transaction.occurred_on),
            extract("month", Transaction.occurred_on),
            Transaction.type,
            func.sum(Transaction.amount),
        )
        .where(
            Transaction.user_id == user.id,
            Transaction.occurred_on >= first,
            Transaction.occurred_on < next_month(last),
        )
        .group_by(
            extract("year", Transaction.occurred_on),
            extract("month", Transaction.occurred_on),
            Transaction.type,
        )
    ).all()

    buckets: dict[str, dict[str, Decimal]] = {}
    cursor = first
    while cursor <= last:  # include empty months so charts have no gaps
        buckets[month_label(cursor)] = {"income": ZERO, "expense": ZERO}
        cursor = next_month(cursor)
    for year, month, tx_type, total in rows:
        label = f"{int(year):04d}-{int(month):02d}"
        if label in buckets:
            buckets[label][tx_type.value] = q2(total)

    return [
        TrendPoint(month=label, income=v["income"], expense=v["expense"], net=v["income"] - v["expense"])
        for label, v in buckets.items()
    ]
