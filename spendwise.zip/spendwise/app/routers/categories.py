from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import delete, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Budget, Category, Transaction, User
from ..schemas import CategoryCreate, CategoryOut, CategoryUpdate
from ..security import get_current_user
from ..services import get_owned_category

router = APIRouter(prefix="/categories", tags=["categories"])


def _conflict() -> HTTPException:
    return HTTPException(status.HTTP_409_CONFLICT, "Category name already exists")


@router.post("", response_model=CategoryOut, status_code=status.HTTP_201_CREATED)
def create_category(
    payload: CategoryCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    if db.scalar(select(Category).where(Category.user_id == user.id, Category.name == payload.name)):
        raise _conflict()
    cat = Category(user_id=user.id, name=payload.name, keywords=payload.keywords)
    db.add(cat)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise _conflict()
    return cat


@router.get("", response_model=list[CategoryOut])
def list_categories(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.scalars(select(Category).where(Category.user_id == user.id).order_by(Category.name)).all()


@router.patch("/{category_id}", response_model=CategoryOut)
def update_category(
    category_id: int,
    payload: CategoryUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    cat = get_owned_category(db, user.id, category_id)
    data = payload.model_dump(exclude_unset=True)
    if not data:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "No fields to update")
    if data.get("name") is not None:
        cat.name = data["name"]
    if data.get("keywords") is not None:
        cat.keywords = data["keywords"]
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise _conflict()
    return cat


@router.delete("/{category_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_category(
    category_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    cat = get_owned_category(db, user.id, category_id)
    # Do this explicitly so behaviour is identical on SQLite (FKs off) and PostgreSQL.
    # One DB transaction: either everything below happens or nothing does.
    db.execute(update(Transaction).where(Transaction.category_id == cat.id).values(category_id=None))
    db.execute(delete(Budget).where(Budget.category_id == cat.id))
    db.delete(cat)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
