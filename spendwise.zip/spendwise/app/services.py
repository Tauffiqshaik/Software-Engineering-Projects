"""Business logic shared by the routers."""
from datetime import date, datetime
from decimal import ROUND_HALF_UP, Decimal

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .models import Budget, Category, Transaction, TransactionType
from .schemas import BudgetOut, BudgetStatus

CENT = Decimal("0.01")
WARNING_THRESHOLD = 80.0  # percent of budget at which status becomes "warning"


def q2(value) -> Decimal:
    """Normalise any numeric to a 2dp Decimal (SQLite can hand back floats for SUM)."""
    return Decimal(str(value or 0)).quantize(CENT, rounding=ROUND_HALF_UP)


def month_start(month: str) -> date:
    return datetime.strptime(month, "%Y-%m").date().replace(day=1)


def month_label(d: date) -> str:
    return f"{d.year:04d}-{d.month:02d}"


def next_month(d: date) -> date:
    return date(d.year + 1, 1, 1) if d.month == 12 else date(d.year, d.month + 1, 1)


def month_bounds(month: str) -> tuple[date, date]:
    """Half-open [start, end) range, portable across SQLite and PostgreSQL."""
    start = month_start(month)
    return start, next_month(start)


def get_owned_category(db: Session, user_id: int, category_id: int) -> Category:
    cat = db.get(Category, category_id)
    if cat is None or cat.user_id != user_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Category not found")
    return cat


def auto_categorize(db: Session, user_id: int, description: str) -> int | None:
    """Pick the category whose longest keyword appears in the description."""
    text = description.lower()
    best: tuple[int, int] | None = None  # (keyword length, category id)
    for cat in db.scalars(select(Category).where(Category.user_id == user_id)):
        for kw in cat.keywords or []:
            if kw and kw in text and (best is None or len(kw) > best[0]):
                best = (len(kw), cat.id)
    return best[1] if best else None


def spent_by_category(db: Session, user_id: int, start: date, end: date) -> dict[int | None, Decimal]:
    rows = db.execute(
        select(Transaction.category_id, func.sum(Transaction.amount))
        .where(
            Transaction.user_id == user_id,
            Transaction.type == TransactionType.expense,
            Transaction.occurred_on >= start,
            Transaction.occurred_on < end,
        )
        .group_by(Transaction.category_id)
    ).all()
    return {cat_id: q2(total) for cat_id, total in rows}


def budget_out(b: Budget) -> BudgetOut:
    return BudgetOut(
        id=b.id,
        category_id=b.category_id,
        month=month_label(b.month),
        limit_amount=q2(b.limit_amount),
    )


def budget_status(b: Budget, category_name: str, spent: Decimal) -> BudgetStatus:
    limit = q2(b.limit_amount)
    percent = float((spent / limit * 100).quantize(Decimal("0.1"))) if limit else 0.0
    if spent > limit:
        state = "exceeded"
    elif percent >= WARNING_THRESHOLD:
        state = "warning"
    else:
        state = "ok"
    return BudgetStatus(
        **budget_out(b).model_dump(),
        category_name=category_name,
        spent=spent,
        remaining=limit - spent,
        percent_used=percent,
        status=state,
    )
