import os

# Must be set before the app is imported.
os.environ["DATABASE_URL"] = "sqlite://"
os.environ["PBKDF2_ITERATIONS"] = "1000"
os.environ["SECRET_KEY"] = "test-secret-key-that-is-long-enough-for-hs256"

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app


@pytest.fixture()
def client():
    engine = create_engine(
        "sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool
    )
    Base.metadata.create_all(engine)
    TestingSession = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

    def override_get_db():
        db = TestingSession()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:  # note: lifespan also runs create_all on the module engine; harmless
        yield c
    app.dependency_overrides.clear()
    engine.dispose()


def _register_and_login(client: TestClient, email: str) -> dict:
    password = "correct-horse-battery"
    r = client.post("/auth/register", json={"email": email, "password": password})
    assert r.status_code == 201, r.text
    r = client.post("/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture()
def auth(client):
    return _register_and_login(client, "alice@example.com")


@pytest.fixture()
def other_auth(client):
    return _register_and_login(client, "bob@example.com")


@pytest.fixture()
def make_category(client, auth):
    def _make(name="Food", keywords=None, headers=None):
        r = client.post(
            "/categories",
            json={"name": name, "keywords": keywords or []},
            headers=headers or auth,
        )
        assert r.status_code == 201, r.text
        return r.json()

    return _make


@pytest.fixture()
def make_tx(client, auth):
    def _make(amount="10.00", type="expense", on="2026-03-10", category_id=None, desc="", headers=None, **kw):
        body = {"amount": amount, "type": type, "occurred_on": on, "description": desc}
        if category_id is not None:
            body["category_id"] = category_id
        r = client.post("/transactions", json=body, headers=headers or auth, **kw)
        assert r.status_code == 201, r.text
        return r.json()

    return _make
