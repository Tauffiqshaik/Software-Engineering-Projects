import pytest


# ------------------------------------------------------- incorrect data
@pytest.mark.parametrize(
    "patch",
    [
        {"amount": "0"},  # must be > 0
        {"amount": "-5.00"},
        {"amount": "10.999"},  # too many decimals: rejected, not rounded
        {"amount": "abc"},
        {"amount": None},
        {"type": "transfer"},  # not an enum member
        {"occurred_on": "2026-13-45"},
        {"occurred_on": "not-a-date"},
        {"occurred_on": "2999-01-01"},  # future
        {"occurred_on": "1900-01-01"},  # too old
        {"description": "x" * 256},
    ],
)
def test_invalid_transaction_rejected(client, auth, patch):
    body = {"amount": "10.00", "type": "expense", "occurred_on": "2026-03-10", **patch}
    r = client.post("/transactions", json=body, headers=auth)
    assert r.status_code == 422, r.text


def test_missing_required_fields(client, auth):
    assert client.post("/transactions", json={}, headers=auth).status_code == 422
    assert client.post("/transactions", json={"amount": "5"}, headers=auth).status_code == 422


def test_unknown_category_is_404(client, auth):
    r = client.post(
        "/transactions",
        json={"amount": "5", "type": "expense", "occurred_on": "2026-03-10", "category_id": 9999},
        headers=auth,
    )
    assert r.status_code == 404


def test_cannot_use_another_users_category(client, auth, other_auth, make_category):
    bobs = make_category("Bobs", headers=other_auth)
    r = client.post(
        "/transactions",
        json={"amount": "5", "type": "expense", "occurred_on": "2026-03-10", "category_id": bobs["id"]},
        headers=auth,
    )
    assert r.status_code == 404


def test_money_is_exact(client, auth, make_tx):
    make_tx(amount="0.10")
    make_tx(amount="0.20")
    r = client.get("/reports/monthly", params={"month": "2026-03"}, headers=auth)
    assert r.json()["total_expense"] == "0.30"  # would be 0.30000000000000004 with floats


# ------------------------------------------------- duplicate requests
def test_idempotency_key_prevents_duplicates(client, auth):
    body = {"amount": "42.50", "type": "expense", "occurred_on": "2026-03-10", "description": "Lunch"}
    h = {**auth, "Idempotency-Key": "abc-123"}

    first = client.post("/transactions", json=body, headers=h)
    second = client.post("/transactions", json=body, headers=h)
    third = client.post("/transactions", json=body, headers=h)

    assert first.status_code == 201
    assert second.status_code == 201
    assert second.headers.get("Idempotent-Replay") == "true"
    assert first.headers.get("Idempotent-Replay") is None
    assert first.json() == second.json() == third.json()
    assert client.get("/transactions", headers=auth).json()["total"] == 1


def test_idempotency_key_reused_with_different_body_conflicts(client, auth):
    h = {**auth, "Idempotency-Key": "k1"}
    a = {"amount": "10", "type": "expense", "occurred_on": "2026-03-10"}
    b = {"amount": "99", "type": "expense", "occurred_on": "2026-03-10"}
    assert client.post("/transactions", json=a, headers=h).status_code == 201
    assert client.post("/transactions", json=b, headers=h).status_code == 409
    assert client.get("/transactions", headers=auth).json()["total"] == 1


def test_different_idempotency_keys_create_separate_transactions(client, auth):
    body = {"amount": "10", "type": "expense", "occurred_on": "2026-03-10"}
    client.post("/transactions", json=body, headers={**auth, "Idempotency-Key": "a"})
    client.post("/transactions", json=body, headers={**auth, "Idempotency-Key": "b"})
    assert client.get("/transactions", headers=auth).json()["total"] == 2


def test_idempotency_keys_are_scoped_per_user(client, auth, other_auth):
    body = {"amount": "10", "type": "expense", "occurred_on": "2026-03-10"}
    a = client.post("/transactions", json=body, headers={**auth, "Idempotency-Key": "same"})
    b = client.post("/transactions", json=body, headers={**other_auth, "Idempotency-Key": "same"})
    assert a.status_code == b.status_code == 201
    assert a.json()["id"] != b.json()["id"]


def test_failed_request_does_not_burn_the_key(client, auth):
    h = {**auth, "Idempotency-Key": "retry-me"}
    bad = {"amount": "-1", "type": "expense", "occurred_on": "2026-03-10"}
    good = {"amount": "1", "type": "expense", "occurred_on": "2026-03-10"}
    assert client.post("/transactions", json=bad, headers=h).status_code == 422
    assert client.post("/transactions", json=good, headers=h).status_code == 201


# -------------------------------------------------- DB transactionality
def test_bulk_is_all_or_nothing(client, auth):
    items = [
        {"amount": "5", "type": "expense", "occurred_on": "2026-03-01"},
        {"amount": "6", "type": "expense", "occurred_on": "2026-03-02"},
        {"amount": "-1", "type": "expense", "occurred_on": "2026-03-03"},  # invalid
    ]
    assert client.post("/transactions/bulk", json={"items": items}, headers=auth).status_code == 422
    assert client.get("/transactions", headers=auth).json()["total"] == 0


def test_bulk_with_unknown_category_saves_nothing(client, auth):
    items = [
        {"amount": "5", "type": "expense", "occurred_on": "2026-03-01"},
        {"amount": "6", "type": "expense", "occurred_on": "2026-03-02", "category_id": 777},
    ]
    assert client.post("/transactions/bulk", json={"items": items}, headers=auth).status_code == 404
    assert client.get("/transactions", headers=auth).json()["total"] == 0


def test_bulk_success_and_limits(client, auth):
    items = [{"amount": "5", "type": "expense", "occurred_on": "2026-03-01"}] * 3
    r = client.post("/transactions/bulk", json={"items": items}, headers=auth)
    assert r.status_code == 201 and len(r.json()) == 3
    assert client.post("/transactions/bulk", json={"items": []}, headers=auth).status_code == 422
    too_many = [items[0]] * 101
    assert client.post("/transactions/bulk", json={"items": too_many}, headers=auth).status_code == 422


# ---------------------------------------------------- categorization
def test_auto_categorize_by_keyword(client, auth, make_category, make_tx):
    food = make_category("Food", ["swiggy", "zomato", "restaurant"])
    travel = make_category("Travel", ["uber", "ola"])
    assert make_tx(desc="Swiggy order #12")["category_id"] == food["id"]
    assert make_tx(desc="UBER trip")["category_id"] == travel["id"]
    assert make_tx(desc="something unrelated")["category_id"] is None


def test_explicit_category_beats_keywords(client, auth, make_category, make_tx):
    food = make_category("Food", ["swiggy"])
    other = make_category("Other")
    assert make_tx(desc="swiggy", category_id=other["id"])["category_id"] == other["id"]


def test_deleting_category_uncategorizes_transactions_and_removes_budgets(
    client, auth, make_category, make_tx
):
    cat = make_category("Food")
    tx = make_tx(category_id=cat["id"])
    client.post(
        "/budgets", json={"category_id": cat["id"], "month": "2026-03", "limit_amount": "100"}, headers=auth
    )
    assert client.delete(f"/categories/{cat['id']}", headers=auth).status_code == 204
    assert client.get(f"/transactions/{tx['id']}", headers=auth).json()["category_id"] is None
    assert client.get("/budgets", headers=auth).json() == []


def test_duplicate_category_name_conflicts(client, auth, make_category):
    make_category("Food")
    assert client.post("/categories", json={"name": "Food"}, headers=auth).status_code == 409
    # different user may reuse the name
    assert client.post("/auth/register", json={"email": "c@example.com", "password": "longenough1"}).status_code == 201


# ----------------------------------------------------------- CRUD/authz
def test_update_and_delete(client, auth, make_tx):
    tx = make_tx(amount="10.00")
    r = client.patch(f"/transactions/{tx['id']}", json={"amount": "12.34", "description": "edited"}, headers=auth)
    assert r.status_code == 200 and r.json()["amount"] == "12.34" and r.json()["description"] == "edited"
    assert client.patch(f"/transactions/{tx['id']}", json={}, headers=auth).status_code == 422
    assert client.patch(f"/transactions/{tx['id']}", json={"amount": None}, headers=auth).status_code == 422
    assert client.patch(f"/transactions/{tx['id']}", json={"amount": "-3"}, headers=auth).status_code == 422
    assert client.delete(f"/transactions/{tx['id']}", headers=auth).status_code == 204
    assert client.get(f"/transactions/{tx['id']}", headers=auth).status_code == 404


def test_users_cannot_touch_each_others_transactions(client, auth, other_auth, make_tx):
    tx = make_tx()
    assert client.get(f"/transactions/{tx['id']}", headers=other_auth).status_code == 404
    assert client.patch(f"/transactions/{tx['id']}", json={"amount": "1"}, headers=other_auth).status_code == 404
    assert client.delete(f"/transactions/{tx['id']}", headers=other_auth).status_code == 404
    assert client.get("/transactions", headers=other_auth).json()["total"] == 0
