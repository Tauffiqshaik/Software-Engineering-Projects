import csv
import io

import pytest


@pytest.fixture()
def seeded(client, auth, make_category, make_tx):
    food = make_category("Food")
    rent = make_category("Rent")
    make_tx("10.00", on="2026-03-01", category_id=food["id"], desc="Coffee beans")
    make_tx("250.00", on="2026-03-05", category_id=food["id"], desc="Dinner out")
    make_tx("1000.00", on="2026-03-02", category_id=rent["id"], desc="March rent")
    make_tx("3000.00", type="income", on="2026-03-03", desc="Salary")
    make_tx("20.00", on="2026-04-01", category_id=food["id"], desc="100% organic_veg")
    return {"food": food, "rent": rent}


def test_default_sort_newest_first(client, auth, seeded):
    items = client.get("/transactions", headers=auth).json()["items"]
    dates = [i["occurred_on"] for i in items]
    assert dates == sorted(dates, reverse=True)


def test_sort_by_amount_asc(client, auth, seeded):
    items = client.get("/transactions", params={"sort_by": "amount", "order": "asc"}, headers=auth).json()["items"]
    amounts = [float(i["amount"]) for i in items]
    assert amounts == sorted(amounts)


def test_invalid_sort_field_rejected(client, auth, seeded):
    assert client.get("/transactions", params={"sort_by": "password"}, headers=auth).status_code == 422
    assert client.get("/transactions", params={"order": "sideways"}, headers=auth).status_code == 422


def test_filters(client, auth, seeded):
    def count(**p):
        r = client.get("/transactions", params=p, headers=auth)
        assert r.status_code == 200, r.text
        return r.json()["total"]

    assert count(type="income") == 1
    assert count(type="expense") == 4
    assert count(category_id=seeded["food"]["id"]) == 3
    assert count(date_from="2026-03-02", date_to="2026-03-03") == 2
    assert count(min_amount=100) == 3
    assert count(max_amount=20) == 2
    assert count(q="rent") == 1
    assert count(q="COFFEE") == 1  # case-insensitive
    assert count(type="expense", category_id=seeded["food"]["id"], date_from="2026-03-01", date_to="2026-03-31") == 2


def test_search_treats_wildcards_literally(client, auth, seeded):
    assert client.get("/transactions", params={"q": "%"}, headers=auth).json()["total"] == 1
    assert client.get("/transactions", params={"q": "organic_veg"}, headers=auth).json()["total"] == 1
    assert client.get("/transactions", params={"q": "organic_ veg"}, headers=auth).json()["total"] == 0


def test_bad_filters_rejected(client, auth, seeded):
    assert client.get("/transactions", params={"date_from": "2026-04-01", "date_to": "2026-03-01"}, headers=auth).status_code == 422
    assert client.get("/transactions", params={"min_amount": 10, "max_amount": 5}, headers=auth).status_code == 422
    assert client.get("/transactions", params={"min_amount": -1}, headers=auth).status_code == 422
    assert client.get("/transactions", params={"type": "bogus"}, headers=auth).status_code == 422
    assert client.get("/transactions", params={"date_from": "yesterday"}, headers=auth).status_code == 422


def test_pagination(client, auth, seeded):
    p1 = client.get("/transactions", params={"page": 1, "page_size": 2}, headers=auth).json()
    p2 = client.get("/transactions", params={"page": 2, "page_size": 2}, headers=auth).json()
    p3 = client.get("/transactions", params={"page": 3, "page_size": 2}, headers=auth).json()
    assert (p1["total"], p1["pages"], len(p1["items"])) == (5, 3, 2)
    assert len(p2["items"]) == 2 and len(p3["items"]) == 1
    ids = [i["id"] for p in (p1, p2, p3) for i in p["items"]]
    assert len(ids) == len(set(ids)) == 5  # no overlap, nothing missing
    beyond = client.get("/transactions", params={"page": 9, "page_size": 2}, headers=auth).json()
    assert beyond["items"] == [] and beyond["total"] == 5


def test_pagination_bounds(client, auth):
    assert client.get("/transactions", params={"page": 0}, headers=auth).status_code == 422
    assert client.get("/transactions", params={"page_size": 0}, headers=auth).status_code == 422
    assert client.get("/transactions", params={"page_size": 101}, headers=auth).status_code == 422


def test_pagination_stable_with_equal_sort_values(client, auth, make_tx):
    for _ in range(7):
        make_tx("5.00", on="2026-03-01")
    seen = []
    for page in (1, 2, 3, 4):
        seen += [i["id"] for i in client.get("/transactions", params={"page": page, "page_size": 2, "sort_by": "amount"}, headers=auth).json()["items"]]
    assert len(seen) == len(set(seen)) == 7


def test_empty_result(client, auth):
    body = client.get("/transactions", headers=auth).json()
    assert body == {"items": [], "total": 0, "page": 1, "page_size": 20, "pages": 0}


# ----------------------------------------------------------------- export
def test_export_csv_respects_filters(client, auth, seeded):
    r = client.get("/transactions/export", params={"type": "income"}, headers=auth)
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("text/csv")
    assert "attachment" in r.headers["content-disposition"]
    rows = list(csv.reader(io.StringIO(r.text)))
    assert rows[0] == ["id", "date", "type", "amount", "category", "description"]
    assert len(rows) == 2 and rows[1][2:] == ["income", "3000.00", "", "Salary"]


def test_export_blocks_csv_formula_injection(client, auth, make_tx):
    make_tx(desc="=HYPERLINK(\"http://evil\",\"x\")")
    make_tx(desc="+1+1")
    rows = list(csv.reader(io.StringIO(client.get("/transactions/export", headers=auth).text)))[1:]
    assert all(r[5].startswith("'") for r in rows)


def test_export_only_includes_own_data(client, auth, other_auth, seeded):
    rows = list(csv.reader(io.StringIO(client.get("/transactions/export", headers=other_auth).text)))
    assert len(rows) == 1  # header only
