import pytest


def _budget(client, auth, cat_id, month="2026-03", limit="100.00"):
    return client.post(
        "/budgets", json={"category_id": cat_id, "month": month, "limit_amount": limit}, headers=auth
    )


def test_create_and_list_budget(client, auth, make_category):
    cat = make_category()
    r = _budget(client, auth, cat["id"])
    assert r.status_code == 201
    assert r.json()["month"] == "2026-03" and r.json()["limit_amount"] == "100.00"
    assert len(client.get("/budgets", headers=auth).json()) == 1
    assert client.get("/budgets", params={"month": "2026-04"}, headers=auth).json() == []


def test_duplicate_budget_conflicts(client, auth, make_category):
    cat = make_category()
    assert _budget(client, auth, cat["id"]).status_code == 201
    assert _budget(client, auth, cat["id"]).status_code == 409
    assert _budget(client, auth, cat["id"], month="2026-04").status_code == 201  # other month is fine


@pytest.mark.parametrize(
    "body",
    [
        {"month": "2026-13", "limit_amount": "10"},
        {"month": "2026-3", "limit_amount": "10"},
        {"month": "March", "limit_amount": "10"},
        {"month": "2026-03", "limit_amount": "0"},
        {"month": "2026-03", "limit_amount": "-10"},
        {"month": "2026-03", "limit_amount": "10.001"},
        {"month": "2026-03"},
    ],
)
def test_invalid_budget_rejected(client, auth, make_category, body):
    cat = make_category()
    r = client.post("/budgets", json={"category_id": cat["id"], **body}, headers=auth)
    assert r.status_code == 422


def test_budget_for_unknown_or_foreign_category(client, auth, other_auth, make_category):
    assert _budget(client, auth, 12345).status_code == 404
    bobs = make_category("Bobs", headers=other_auth)
    assert _budget(client, auth, bobs["id"]).status_code == 404


def test_update_and_delete_budget(client, auth, other_auth, make_category):
    cat = make_category()
    b = _budget(client, auth, cat["id"]).json()
    r = client.patch(f"/budgets/{b['id']}", json={"limit_amount": "250.50"}, headers=auth)
    assert r.json()["limit_amount"] == "250.50"
    assert client.patch(f"/budgets/{b['id']}", json={"limit_amount": "5"}, headers=other_auth).status_code == 404
    assert client.delete(f"/budgets/{b['id']}", headers=other_auth).status_code == 404
    assert client.delete(f"/budgets/{b['id']}", headers=auth).status_code == 204


def test_budget_status_transitions(client, auth, make_category, make_tx):
    cat = make_category("Food")
    _budget(client, auth, cat["id"], limit="100.00")

    def status():
        return client.get("/budgets/status", params={"month": "2026-03"}, headers=auth).json()[0]

    s = status()
    assert (s["spent"], s["remaining"], s["status"]) == ("0.00", "100.00", "ok")

    make_tx("79.00", category_id=cat["id"])
    assert status()["status"] == "ok"

    make_tx("1.00", category_id=cat["id"])  # exactly 80%
    s = status()
    assert s["status"] == "warning" and s["percent_used"] == 80.0

    make_tx("20.00", category_id=cat["id"])  # exactly at limit: not exceeded
    assert status()["status"] == "warning"

    make_tx("0.01", category_id=cat["id"])
    s = status()
    assert s["status"] == "exceeded" and s["remaining"] == "-0.01"


def test_budget_ignores_income_and_other_months(client, auth, make_category, make_tx):
    cat = make_category("Food")
    _budget(client, auth, cat["id"], limit="100")
    make_tx("500", type="income", category_id=cat["id"])
    make_tx("50", on="2026-02-28", category_id=cat["id"])
    make_tx("50", on="2026-04-01", category_id=cat["id"])
    s = client.get("/budgets/status", params={"month": "2026-03"}, headers=auth).json()[0]
    assert s["spent"] == "0.00"


# ----------------------------------------------------------------- reports
def test_monthly_report(client, auth, make_category, make_tx):
    food = make_category("Food")
    rent = make_category("Rent")
    make_tx("30.00", category_id=food["id"])
    make_tx("20.00", category_id=food["id"])
    make_tx("900.00", category_id=rent["id"])
    make_tx("15.00")  # uncategorized
    make_tx("2000.00", type="income")
    make_tx("999.00", on="2026-02-28")  # other month
    _budget(client, auth, food["id"], limit="40.00")

    r = client.get("/reports/monthly", params={"month": "2026-03"}, headers=auth)
    assert r.status_code == 200
    rep = r.json()
    assert rep["total_expense"] == "965.00"
    assert rep["total_income"] == "2000.00"
    assert rep["net"] == "1035.00"
    assert rep["transaction_count"] == 5
    assert [c["category_name"] for c in rep["expenses_by_category"]] == ["Rent", "Food", "Uncategorized"]
    assert rep["expenses_by_category"][1] == {"category_id": food["id"], "category_name": "Food", "total": "50.00", "count": 2}
    assert rep["budgets"][0]["status"] == "exceeded"


def test_report_for_empty_month(client, auth):
    rep = client.get("/reports/monthly", params={"month": "2020-01"}, headers=auth).json()
    assert rep["total_expense"] == "0.00" and rep["net"] == "0.00"
    assert rep["expenses_by_category"] == [] and rep["budgets"] == []


def test_report_month_boundaries(client, auth, make_tx):
    make_tx("1", on="2026-03-01")
    make_tx("2", on="2026-03-31")
    make_tx("4", on="2026-04-01")
    rep = client.get("/reports/monthly", params={"month": "2026-03"}, headers=auth).json()
    assert rep["total_expense"] == "3.00"
    dec = client.get("/reports/monthly", params={"month": "2025-12"}, headers=auth).json()
    assert dec["total_expense"] == "0.00"  # December -> January rollover works


def test_report_invalid_month(client, auth):
    assert client.get("/reports/monthly", params={"month": "2026-00"}, headers=auth).status_code == 422
    assert client.get("/reports/monthly", headers=auth).status_code == 422


def test_report_isolated_per_user(client, auth, other_auth, make_tx):
    make_tx("500")
    rep = client.get("/reports/monthly", params={"month": "2026-03"}, headers=other_auth).json()
    assert rep["total_expense"] == "0.00"


def test_trend_fills_empty_months_and_crosses_year(client, auth, make_tx):
    make_tx("10", on="2025-12-15")
    make_tx("100", type="income", on="2026-02-10")
    pts = client.get("/reports/trend", params={"end_month": "2026-02", "months": 3}, headers=auth).json()
    assert [p["month"] for p in pts] == ["2025-12", "2026-01", "2026-02"]
    assert [p["expense"] for p in pts] == ["10.00", "0.00", "0.00"]
    assert [p["net"] for p in pts] == ["-10.00", "0.00", "100.00"]


def test_trend_bounds(client, auth):
    assert client.get("/reports/trend", params={"end_month": "2026-02", "months": 0}, headers=auth).status_code == 422
    assert client.get("/reports/trend", params={"end_month": "2026-02", "months": 25}, headers=auth).status_code == 422
