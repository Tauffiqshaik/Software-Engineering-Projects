def test_register_login_me(client):
    r = client.post("/auth/register", json={"email": "A@Example.com", "password": "longenough1"})
    assert r.status_code == 201
    assert r.json()["email"] == "a@example.com"  # normalised
    assert "password" not in r.text

    token = client.post(
        "/auth/login", json={"email": "a@example.com", "password": "longenough1"}
    ).json()["access_token"]
    me = client.get("/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.status_code == 200 and me.json()["email"] == "a@example.com"


def test_duplicate_email_rejected(client):
    body = {"email": "dup@example.com", "password": "longenough1"}
    assert client.post("/auth/register", json=body).status_code == 201
    assert client.post("/auth/register", json=body).status_code == 409


def test_duplicate_email_case_insensitive(client):
    assert client.post("/auth/register", json={"email": "x@example.com", "password": "longenough1"}).status_code == 201
    assert client.post("/auth/register", json={"email": "X@EXAMPLE.COM", "password": "longenough1"}).status_code == 409


def test_bad_registration_input(client):
    assert client.post("/auth/register", json={"email": "nope", "password": "longenough1"}).status_code == 422
    assert client.post("/auth/register", json={"email": "a@b.co", "password": "short"}).status_code == 422
    assert client.post("/auth/register", json={}).status_code == 422


def test_wrong_password_and_unknown_user_look_identical(client):
    client.post("/auth/register", json={"email": "a@example.com", "password": "longenough1"})
    wrong = client.post("/auth/login", json={"email": "a@example.com", "password": "wrongwrong"})
    unknown = client.post("/auth/login", json={"email": "zz@example.com", "password": "wrongwrong"})
    assert wrong.status_code == unknown.status_code == 401
    assert wrong.json() == unknown.json()


def test_endpoints_require_auth(client):
    for path in ["/transactions", "/categories", "/budgets", "/reports/monthly?month=2026-01"]:
        assert client.get(path).status_code == 401
    assert client.get("/transactions", headers={"Authorization": "Bearer garbage"}).status_code == 401
