# SpendWise — Personal Finance Management API

A backend for tracking transactions, setting category budgets and getting monthly spending reports.

**Stack:** Python 3.12 · FastAPI · SQLAlchemy 2 · PostgreSQL · Pydantic v2 · JWT · Docker · pytest

## Features

| Area | What it does |
|---|---|
| Auth | Register/login, PBKDF2-SHA256 password hashing, JWT bearer tokens, per-user data isolation |
| Categories | CRUD, plus **keywords** for auto-categorisation (`"swiggy order"` → *Food*) |
| Transactions | CRUD, **filter** (type, category, date range, amount range, text search), **sort**, **paginate**, **CSV export**, **bulk import** |
| Budgets | Monthly limit per category; status is `ok` / `warning` (≥80%) / `exceeded` |
| Reports | Monthly summary (income, expense, net, per-category, budget status) and N-month trend |

## Run it

```bash
docker compose up --build        # API on http://localhost:8000, docs at /docs
```

Or locally with SQLite (no Docker):

```bash
pip install -r requirements-dev.txt
uvicorn app.main:app --reload
pytest
```

Set `SECRET_KEY` for anything other than local development.

## Design decisions worth talking about

- **Money is `NUMERIC(12,2)` / `Decimal`, never float.** Input with more than 2 decimals (`10.999`) is rejected rather than silently rounded; a test shows `0.10 + 0.20 == 0.30`.
- **Idempotent POST.** Send an `Idempotency-Key` header and a retried request returns the original response (with `Idempotent-Replay: true`) instead of creating a duplicate. The key and the transaction row are committed in the **same DB transaction**, a unique `(user_id, key)` constraint resolves concurrent races, and reusing a key with a *different* body returns `409`.
- **Atomic bulk import.** `POST /transactions/bulk` is all-or-nothing: one bad row and nothing is saved.
- **Deleting a category** un-categorises its transactions and removes its budgets in one transaction, with explicit statements so behaviour is identical on SQLite and PostgreSQL.
- **Stable pagination.** Sorting adds `id` as a tiebreaker so pages never overlap when many rows share a value.
- **Portable month queries.** Reports use half-open date ranges `[start, next_month)` instead of `strftime`/`date_trunc`, so they run on both databases and can use the `(user_id, occurred_on)` index.
- **Security basics.** Ownership checks return `404` (not `403`) so IDs can't be probed; login errors don't reveal whether an email exists; `LIKE` wildcards in search are escaped; sort fields are whitelisted; CSV export neutralises spreadsheet formula injection (`=`, `+`, `-`, `@`).

## API overview

```
POST   /auth/register | /auth/login          GET /auth/me
GET    /categories    POST /categories       PATCH|DELETE /categories/{id}
POST   /transactions  (Idempotency-Key)      POST /transactions/bulk
GET    /transactions?type=&category_id=&date_from=&date_to=&min_amount=&max_amount=&q=
                    &sort_by=occurred_on|amount|created_at|id&order=asc|desc&page=&page_size=
GET    /transactions/export                  (same filters, returns CSV)
GET|PATCH|DELETE /transactions/{id}
POST   /budgets       GET /budgets?month=    GET /budgets/status?month=2026-03
GET    /reports/monthly?month=2026-03        GET /reports/trend?end_month=2026-03&months=6
```

## Tests

`pytest` runs 68 tests covering:

- **Duplicate requests:** same idempotency key, key reuse with a different body, per-user key scoping, failed requests not burning a key, duplicate emails (case-insensitive), duplicate categories and budgets.
- **Incorrect data:** zero/negative/over-precise amounts, bad enums, impossible and future dates, oversized fields, unknown or foreign category IDs, bad month formats, invalid sort fields, inverted ranges, out-of-range pagination.
- **Transactionality:** bulk import rollback, category deletion cascade.
- **Business logic:** budget thresholds (exactly 80% and exactly 100%), month and year boundaries, empty months in trends, user isolation.

## Possible extensions

Alembic migrations, recurring transactions, multi-currency, rate limiting, refresh tokens, and a Postgres service container in CI.
