# CodeReview AI — Automated Code Review Platform

Submit a code snippet, a pasted diff or a **GitHub pull request** and get review comments with **line references**, severity and a suggested fix. Static analysis finds bugs, security problems and maintainability issues; an optional **LLM pass** adds context-aware findings. Reviewers mark findings as *confirmed* or *false positive*, and the system learns: suppressed findings stay suppressed, and per-rule accuracy is tracked.

**Stack:** Python 3.12 · FastAPI · SQLAlchemy · PostgreSQL · React (Vite) · GitHub REST API · Anthropic API · Docker · GitHub Actions

## Run it

```bash
cp .env.example .env        # optional: add GITHUB_TOKEN / ANTHROPIC_API_KEY
docker compose up --build   # UI http://localhost:3000   API docs http://localhost:8000/docs
```

Without Docker:

```bash
cd backend  && pip install -r requirements-dev.txt && uvicorn app.main:app --reload && pytest
cd frontend && npm install && npm run dev      # http://localhost:5173 (proxies /api to :8000)
```

Static analysis works with no keys at all. `ANTHROPIC_API_KEY` enables the AI pass; `GITHUB_TOKEN` enables PR reviews.

### Troubleshooting

- **"Request failed (500)" / "API is unavailable" in the UI:** the frontend can't reach the backend. With `npm run dev`, the backend must be running separately on port 8000 (`cd backend && uvicorn app.main:app --port 8000`); the Vite dev server answers `/api/*` with an empty 500 when nothing is listening. Check http://localhost:8000/health.
- **With Docker:** `docker compose logs backend` (the backend waits for Postgres to be healthy).

## How a review works

```
snippet / diff / PR ──► fetch files ──► static analyzers ──► (LLM pass) ──► validate ──► fingerprint ──► store
                         (GitHub API)    AST + patterns       optional       line must      suppress known
                                                                             be changed     false positives
```

1. **PR mode** reads the PR's files, parses each patch to find the *changed lines*, fetches the file at the head commit, analyses the **whole file** (so the Python AST parses correctly) and keeps only findings on changed lines — a reviewer shouldn't be told about code the author didn't touch.
2. **Static rules** (`GET /rules`, 25+): Python AST checks for `eval`/`exec`, `shell=True`, unsafe `pickle`/`yaml.load`, weak hashes, **SQL built with f-strings/concatenation**, `verify=False`, bare/swallowed `except`, mutable defaults, long functions, cyclomatic complexity, too many params, `== None`, debug mode, `mktemp`; line-based checks for hard-coded secrets, AWS/GitHub tokens, private keys, risky JavaScript (`eval`, `innerHTML`, command injection, `==`, `console.log`) and TODOs.
3. **LLM pass** sends numbered lines and asks for JSON. The reply is treated as untrusted: it must parse, lines must exist and be in the changed set, severity/category must be from the allowed enums, and results duplicating a static finding are dropped. If the LLM fails, the review still succeeds.
4. **Optionally posts** the findings back to the PR as one GitHub review with inline comments (`post_comments: true`).
5. A **webhook** (`POST /webhooks/github`) reviews PRs automatically on open/sync/reopen.

## False-positive tracking

Each finding has a **fingerprint** = `sha256(rule | file | normalised source line)` — based on the line's *text*, not its number. When a finding is marked `false_positive`, the same fingerprint is auto-suppressed in future reviews even if unrelated edits shifted it to a different line. Suppressed findings don't count towards severity totals, and re-opening one lifts the suppression. `GET /stats/rules` reports per-rule counts and **false-positive rate = FP ÷ (FP + confirmed)**, worst rules first, so you know which checks to tune.

## Secure-coding decisions

- **Webhook** requests require a valid `X-Hub-Signature-256` HMAC, compared in constant time; with no secret configured the endpoint refuses to run.
- **Repo names** are validated against GitHub's character set (blocks `../`, query strings and other path tricks) before being placed in a URL; file paths are URL-encoded.
- **Secrets** are never echoed: a hard-coded credential finding doesn't include the value. GitHub error bodies are not passed through to clients.
- **Prompt injection:** reviewed code is wrapped in `<code>` tags with an instruction to treat it as data, *and* the output is validated so a malicious comment can't produce arbitrary findings or fake line numbers.
- **Limits** on snippet size, file size, files per review and comments per review; minified lines are skipped to avoid regex blow-ups.
- Optional `X-API-Key` protection (constant-time compare); least-privilege token guidance in `.env.example`; containers run as non-root.

## API

```
POST /reviews/snippet        {filename, code, use_llm}
POST /reviews/diff           {diff}
POST /reviews/pull-request   {repo: "owner/name", pr_number, use_llm, post_comments}
GET  /reviews  ·  GET|DELETE /reviews/{id}
PATCH /findings/{id}         {status: open | confirmed | false_positive}
GET  /stats/rules  ·  GET /rules  ·  POST /webhooks/github
```

## Tests

`pytest` runs 135 tests (GitHub and the LLM are mocked, so no network or keys are needed):

- **Every rule** has positive and negative cases (e.g. parameterised SQL and `yaml.safe_load` are *not* flagged), plus placeholder-secret handling and changed-line filtering.
- **Diff parsing** edge cases (deleted/new files, added lines that look like headers, "No newline" markers).
- **GitHub client** over a mock transport: auth header, pagination, error mapping without leaking bodies, binary/missing files, URL encoding.
- **LLM output validation:** malformed JSON, hallucinated lines, bad enums, caps, merging, failure tolerance.
- **False-positive workflow:** suppression survives line shifts, is scoped per file and rule, can be lifted, and drives the stats.
- **Webhook security:** missing/forged/wrong-body signatures rejected, unconfigured secret, malformed payloads, background failures contained.

## Known limitations

Static rules are heuristics (no data-flow/taint analysis), so some findings are false positives — which is exactly why triage and suppression exist. Only Python gets AST analysis; other languages use line-based rules. The webhook reviews synchronously in a background task rather than a durable queue; for production use a worker queue (Celery/RQ) and Alembic migrations.
