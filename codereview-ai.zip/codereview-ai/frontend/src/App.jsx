import React, { useCallback, useEffect, useState } from "react";
import { api } from "./api.js";

const SAMPLE = `import hashlib

def login(db, user, password, tags=[]):
    db.execute(f"SELECT * FROM users WHERE name = '{user}'")
    digest = hashlib.md5(password.encode()).hexdigest()
    try:
        return eval(user)
    except:
        pass
`;

function Badge({ children, kind }) {
  return <span className={`badge ${kind}`}>{children}</span>;
}

function Counts({ counts }) {
  return (
    <span className="counts">
      {["high", "medium", "low"].map((s) => (
        <Badge key={s} kind={s}>{counts?.[s] ?? 0} {s}</Badge>
      ))}
    </span>
  );
}

function NewReview({ onDone }) {
  const [mode, setMode] = useState("snippet");
  const [filename, setFilename] = useState("app.py");
  const [code, setCode] = useState(SAMPLE);
  const [diff, setDiff] = useState("");
  const [repo, setRepo] = useState("");
  const [pr, setPr] = useState("");
  const [useLlm, setUseLlm] = useState(true);
  const [postComments, setPostComments] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const review =
        mode === "snippet" ? await api.reviewSnippet(filename, code, useLlm)
        : mode === "diff" ? await api.reviewDiff(diff)
        : await api.reviewPullRequest(repo.trim(), pr, useLlm, postComments);
      onDone(review.id);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="card">
      <div className="tabs" role="tablist">
        {[["snippet", "Code snippet"], ["pr", "GitHub pull request"], ["diff", "Paste diff"]].map(([k, label]) => (
          <button type="button" key={k} role="tab" aria-selected={mode === k} className={mode === k ? "tab active" : "tab"} onClick={() => setMode(k)}>
            {label}
          </button>
        ))}
      </div>

      {mode === "snippet" && (
        <>
          <label>Filename (decides which rules apply)
            <input value={filename} onChange={(e) => setFilename(e.target.value)} required maxLength={255} />
          </label>
          <label>Code
            <textarea value={code} onChange={(e) => setCode(e.target.value)} rows={14} required spellCheck={false} />
          </label>
        </>
      )}
      {mode === "pr" && (
        <div className="row">
          <label className="grow">Repository
            <input value={repo} onChange={(e) => setRepo(e.target.value)} placeholder="owner/name" required pattern="[A-Za-z0-9_.\-]+/[A-Za-z0-9_.\-]+" />
          </label>
          <label>PR number
            <input type="number" min="1" value={pr} onChange={(e) => setPr(e.target.value)} required />
          </label>
        </div>
      )}
      {mode === "diff" && (
        <label><span>Unified diff (output of <code>git diff</code>)</span>
          <textarea value={diff} onChange={(e) => setDiff(e.target.value)} rows={14} required spellCheck={false} />
        </label>
      )}

      <div className="row options">
        {mode !== "diff" && (
          <label className="check"><input type="checkbox" checked={useLlm} onChange={(e) => setUseLlm(e.target.checked)} /> Add AI review pass</label>
        )}
        {mode === "pr" && (
          <label className="check"><input type="checkbox" checked={postComments} onChange={(e) => setPostComments(e.target.checked)} /> Post findings as PR comments</label>
        )}
      </div>

      {error && <p className="error" role="alert">{error}</p>}
      <button className="primary" disabled={busy}>{busy ? "Reviewing…" : "Run review"}</button>
    </form>
  );
}

function FindingCard({ f, onTriage }) {
  return (
    <li className={`finding ${f.status}`}>
      <div className="finding-head">
        <Badge kind={f.severity}>{f.severity}</Badge>
        <Badge kind="category">{f.category}</Badge>
        <code>{f.rule_id}</code>
        {f.source === "llm" && <Badge kind="ai">AI</Badge>}
        <span className="loc">{f.file_path}:{f.line}</span>
      </div>
      {f.code_line && <pre className="code-line"><span className="ln">{f.line}</span>{f.code_line}</pre>}
      <p>{f.message}</p>
      {f.suggestion && <p className="suggestion"><strong>Fix:</strong> {f.suggestion}</p>}
      <div className="triage">
        {f.auto_suppressed && <em>Auto-suppressed: previously marked as a false positive.</em>}
        {["open", "confirmed", "false_positive"].map((s) => (
          <button key={s} className={f.status === s ? "chip active" : "chip"} onClick={() => onTriage(f.id, s)} aria-pressed={f.status === s}>
            {s === "open" ? "Open" : s === "confirmed" ? "Confirm" : "False positive"}
          </button>
        ))}
      </div>
    </li>
  );
}

function ReviewDetail({ id, onDeleted }) {
  const [review, setReview] = useState(null);
  const [error, setError] = useState("");
  const [hideFp, setHideFp] = useState(true);

  useEffect(() => {
    setReview(null);
    setError("");
    api.getReview(id).then(setReview).catch((e) => setError(e.message));
  }, [id]);

  async function triage(findingId, status) {
    try {
      const updated = await api.triage(findingId, status);
      setReview((r) => ({ ...r, findings: r.findings.map((f) => (f.id === findingId ? updated : f)) }));
    } catch (e) {
      setError(e.message);
    }
  }

  if (error) return <p className="error" role="alert">{error}</p>;
  if (!review) return <p>Loading…</p>;

  const shown = review.findings.filter((f) => !hideFp || f.status !== "false_positive");
  const byFile = shown.reduce((acc, f) => ((acc[f.file_path] ||= []).push(f), acc), {});

  return (
    <div className="card">
      <div className="detail-head">
        <div>
          <h2>{review.title || `Review #${review.id}`}</h2>
          <p className="muted">
            {review.source.replace("_", " ")}
            {review.repo && ` · ${review.repo}#${review.pr_number}`} · {review.files_reviewed} file(s)
            {review.llm_used && " · AI pass"}
            {review.comments_posted && " · comments posted to GitHub"}
          </p>
        </div>
        <Counts counts={review.counts} />
      </div>
      <label className="check">
        <input type="checkbox" checked={hideFp} onChange={(e) => setHideFp(e.target.checked)} /> Hide false positives
      </label>
      {shown.length === 0 && <p className="ok">No issues to show. 🎉</p>}
      {Object.entries(byFile).map(([file, fs]) => (
        <section key={file}>
          <h3>{file}</h3>
          <ul className="findings">{fs.map((f) => <FindingCard key={f.id} f={f} onTriage={triage} />)}</ul>
        </section>
      ))}
      <button className="danger" onClick={async () => { await api.deleteReview(review.id); onDeleted(); }}>Delete review</button>
    </div>
  );
}

function Stats() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => { api.ruleStats().then(setStats).catch((e) => setError(e.message)); }, []);
  if (error) return <p className="error">{error}</p>;
  if (!stats) return <p>Loading…</p>;
  return (
    <div className="card">
      <h2>Rule accuracy</h2>
      <p className="muted">False-positive rate = false positives ÷ (false positives + confirmed). Rules at the top need tuning.</p>
      {stats.length === 0 ? <p>No findings yet.</p> : (
        <table>
          <thead><tr><th>Rule</th><th>Title</th><th>Total</th><th>Open</th><th>Confirmed</th><th>False pos.</th><th>FP rate</th></tr></thead>
          <tbody>
            {stats.map((s) => (
              <tr key={s.rule_id}>
                <td><code>{s.rule_id}</code></td><td>{s.title}</td><td>{s.total}</td><td>{s.open}</td><td>{s.confirmed}</td><td>{s.false_positive}</td>
                <td>{s.false_positive_rate == null ? "—" : `${Math.round(s.false_positive_rate * 100)}%`}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default function App() {
  const [view, setView] = useState("new");
  const [selected, setSelected] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [error, setError] = useState("");

  const refresh = useCallback(() => api.listReviews().then(setReviews).catch((e) => setError(e.message)), []);
  useEffect(() => { refresh(); }, [refresh]);

  const open = (id) => { setSelected(id); setView("review"); refresh(); };

  return (
    <div className="layout">
      <aside>
        <h1>CodeReview <span>AI</span></h1>
        <nav>
          <button className={view === "new" ? "nav active" : "nav"} onClick={() => setView("new")}>+ New review</button>
          <button className={view === "stats" ? "nav active" : "nav"} onClick={() => setView("stats")}>Rule accuracy</button>
        </nav>
        <h4>History</h4>
        {error && <p className="error">{error}</p>}
        <ul className="history">
          {reviews.map((r) => (
            <li key={r.id}>
              <button className={view === "review" && selected === r.id ? "hist active" : "hist"} onClick={() => open(r.id)}>
                <strong>{r.title || `Review #${r.id}`}</strong>
                <Counts counts={r.counts} />
              </button>
            </li>
          ))}
          {reviews.length === 0 && <li className="muted">No reviews yet</li>}
        </ul>
      </aside>
      <main>
        {view === "new" && <NewReview onDone={open} />}
        {view === "review" && selected && <ReviewDetail id={selected} onDeleted={() => { setView("new"); refresh(); }} />}
        {view === "stats" && <Stats />}
      </main>
    </div>
  );
}
