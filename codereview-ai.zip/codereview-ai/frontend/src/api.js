const BASE = import.meta.env.VITE_API_URL ?? "/api";
const API_KEY = import.meta.env.VITE_API_KEY ?? "";

async function request(path, options = {}) {
  let res;
  try {
    res = await fetch(`${BASE}${path}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(API_KEY ? { "X-API-Key": API_KEY } : {}),
        ...options.headers,
      },
    });
  } catch {
    throw new Error("Cannot reach the API. Is the backend running on port 8000?");
  }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => null);
  if (data === null && !res.ok && res.status >= 500) {
    // No JSON body = the request never reached the app (dev proxy / nginx error), or it crashed.
    throw new Error(`The API is unavailable (HTTP ${res.status}). Start the backend: uvicorn app.main:app --port 8000 (see README).`);
  }
  if (!res.ok) {
    // FastAPI returns either {detail: "msg"} or {detail: [{loc, msg}, ...]}
    const detail = Array.isArray(data?.detail)
      ? data.detail.map((d) => `${(d.loc || []).slice(1).join(".")}: ${d.msg}`).join("; ")
      : data?.detail;
    throw new Error(detail || `Request failed (${res.status})`);
  }
  return data;
}

const post = (path, body) => request(path, { method: "POST", body: JSON.stringify(body) });

export const api = {
  reviewSnippet: (filename, code, useLlm) => post("/reviews/snippet", { filename, code, use_llm: useLlm }),
  reviewDiff: (diff) => post("/reviews/diff", { diff }),
  reviewPullRequest: (repo, prNumber, useLlm, postComments) =>
    post("/reviews/pull-request", { repo, pr_number: Number(prNumber), use_llm: useLlm, post_comments: postComments }),
  listReviews: () => request("/reviews?limit=50"),
  getReview: (id) => request(`/reviews/${id}`),
  deleteReview: (id) => request(`/reviews/${id}`, { method: "DELETE" }),
  triage: (findingId, status) => request(`/findings/${findingId}`, { method: "PATCH", body: JSON.stringify({ status }) }),
  ruleStats: () => request("/stats/rules"),
};
