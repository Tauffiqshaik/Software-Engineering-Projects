"""Turns source files into a stored Review, including false-positive suppression."""
import hashlib
import re

from sqlalchemy import select
from sqlalchemy.orm import Session

from .analyzers.base import Issue
from .analyzers.engine import SourceFile, analyze_file
from .llm import LLMReviewer
from .models import Finding, Review

SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2}


def fingerprint(rule_id: str, path: str, code_line: str) -> str:
    """Stable identity for a finding. Based on the line's *text*, not its number, so a
    triaged false positive stays suppressed when unrelated edits shift it up or down."""
    normalised = re.sub(r"\s+", " ", code_line).strip()
    return hashlib.sha256(f"{rule_id}|{path}|{normalised}".encode()).hexdigest()


def _false_positive_fingerprints(db: Session, fps: set[str]) -> set[str]:
    if not fps:
        return set()
    return set(
        db.scalars(
            select(Finding.fingerprint).where(Finding.fingerprint.in_(fps), Finding.status == "false_positive")
        )
    )


def _merge_llm(static: list[Issue], llm: list[Issue]) -> list[Issue]:
    """Drop LLM findings that repeat something static analysis already found."""
    seen = {(i.line, i.category) for i in static}
    return static + [i for i in llm if (i.line, i.category) not in seen]


def run_review(
    db: Session,
    *,
    files: list[SourceFile],
    source: str,
    title: str = "",
    repo: str | None = None,
    pr_number: int | None = None,
    head_sha: str | None = None,
    llm: LLMReviewer | None = None,
) -> Review:
    review = Review(source=source, title=title[:255], repo=repo, pr_number=pr_number,
                    head_sha=head_sha, files_reviewed=len(files), llm_used=llm is not None)
    pending: list[tuple[str, str, Issue]] = []  # (path, code_line, issue)

    for f in files:
        issues = analyze_file(f)
        if llm is not None:
            issues = _merge_llm(issues, llm.review(f.path, f.content, f.changed_lines))
        for issue in issues:
            code_line = f.line_text(issue.line)
            pending.append((f.path, code_line, issue))

    known_fps = _false_positive_fingerprints(
        db, {fingerprint(i.rule_id, p, c) for p, c, i in pending}
    )
    pending.sort(key=lambda t: (SEVERITY_ORDER[t[2].severity], t[0], t[2].line))
    for path, code_line, issue in pending:
        fp = fingerprint(issue.rule_id, path, code_line)
        suppressed = fp in known_fps
        review.findings.append(
            Finding(
                file_path=path, line=issue.line, rule_id=issue.rule_id, severity=issue.severity,
                category=issue.category, source=issue.source, message=issue.message,
                suggestion=issue.suggestion, code_line=code_line[:500], fingerprint=fp,
                status="false_positive" if suppressed else "open", auto_suppressed=suppressed,
            )
        )
    db.add(review)
    db.commit()
    return review


def format_github_comment(f: Finding) -> str:
    badge = {"high": "🔴", "medium": "🟠", "low": "🟡"}[f.severity]
    text = f"{badge} **{f.severity.upper()} · {f.category}** (`{f.rule_id}`)\n\n{f.message}"
    if f.suggestion:
        text += f"\n\n**Suggestion:** {f.suggestion}"
    return text
