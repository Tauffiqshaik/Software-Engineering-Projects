from dataclasses import dataclass

SEVERITIES = ("high", "medium", "low")
CATEGORIES = ("security", "bug", "maintainability")


@dataclass(frozen=True)
class Issue:
    rule_id: str
    severity: str
    category: str
    line: int
    message: str
    suggestion: str = ""
    source: str = "static"  # static | llm


# Short catalogue shown by GET /rules.
RULES: dict[str, tuple[str, str, str]] = {}  # rule_id -> (severity, category, title)


def rule(rule_id: str, severity: str, category: str, title: str) -> str:
    assert severity in SEVERITIES and category in CATEGORIES
    RULES[rule_id] = (severity, category, title)
    return rule_id


def make_issue(rule_id: str, line: int, message: str, suggestion: str = "") -> Issue:
    severity, category, _ = RULES[rule_id]
    return Issue(rule_id, severity, category, line, message, suggestion)
