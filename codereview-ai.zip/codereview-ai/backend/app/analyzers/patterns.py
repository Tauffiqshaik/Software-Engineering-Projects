"""Line-based rules that work on any language (secrets, risky JS, TODOs)."""
import re

from .base import Issue, make_issue, rule

SEC_SECRET = rule("SEC001", "high", "security", "Hard-coded credential")
SEC_AWS = rule("SEC002", "high", "security", "AWS access key")
SEC_PRIVKEY = rule("SEC003", "high", "security", "Private key committed")
SEC_GH = rule("SEC004", "high", "security", "GitHub token")
JS_EVAL = rule("JS001", "high", "security", "eval() / new Function()")
JS_HTML = rule("JS002", "high", "security", "Unsafe HTML injection (XSS)")
JS_LOG = rule("JS003", "low", "maintainability", "console.log left in code")
JS_EQ = rule("JS004", "low", "bug", "Loose equality (==/!=)")
JS_EXEC = rule("JS005", "high", "security", "Command execution with dynamic input")
MNT_TODO = rule("MNT001", "low", "maintainability", "TODO/FIXME marker")

JS_EXTS = (".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs")

_SECRET_RE = re.compile(
    r"""(?ix)
    \b[\w.-]*(password|passwd|pwd|secret|api[_-]?key|access[_-]?key|auth[_-]?token|token)[\w.-]*
    \s*[:=]\s*
    (?P<q>["'])(?P<val>[^"'\s]{8,})(?P=q)
    """
)
_PLACEHOLDER_RE = re.compile(r"(?i)^(<.*>|\$\{.*\}|\{\{.*\}\}|x{4,}|\*{4,}|your[_-].*|example.*|changeme|placeholder.*|test.*|dummy.*)$")
_AWS_RE = re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b")
_PRIV_RE = re.compile(r"-----BEGIN (RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----")
_GH_RE = re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b")
_JS_EVAL_RE = re.compile(r"\beval\s*\(|\bnew\s+Function\s*\(")
_JS_HTML_RE = re.compile(r"\.innerHTML\s*=(?!=)|\.outerHTML\s*=(?!=)|document\.write\s*\(|dangerouslySetInnerHTML")
_JS_LOG_RE = re.compile(r"\bconsole\.(log|debug)\s*\(")
_JS_EQ_RE = re.compile(r"[^=!<>]==(?!=)|!=(?!=)")
_JS_EXEC_RE = re.compile(r"""\b(exec|execSync)\s*\(\s*(`[^`]*\$\{|(?:"[^"]*"|'[^']*'|[\w.]+)\s*\+)""")
_TODO_RE = re.compile(r"\b(TODO|FIXME|HACK|XXX)\b")
_COMMENT_PREFIX = re.compile(r"^\s*(#|//|/\*|\*)")


def _strip_js_strings(line: str) -> str:
    """Blank out string literals so '==' inside text doesn't trigger JS004."""
    return re.sub(r"""(["'`])(?:\\.|(?!\1).)*\1""", '""', line)


def analyze_lines(path: str, lines: dict[int, str]) -> list[Issue]:
    """`lines` maps 1-based line number -> text (may be sparse, e.g. only changed lines)."""
    out: list[Issue] = []
    is_js = path.lower().endswith(JS_EXTS)

    for no, text in lines.items():
        if len(text) > 2000:  # minified bundles: skip, regexes would be slow and useless
            continue

        m = _SECRET_RE.search(text)
        if m and not _PLACEHOLDER_RE.match(m.group("val")):
            out.append(make_issue(SEC_SECRET, no,
                                  "A credential appears to be hard-coded in source (value hidden here). Anyone with repo access can read it, and git history keeps it forever.",
                                  "Load it from an environment variable or secret manager, and rotate this value."))
        if _AWS_RE.search(text):
            out.append(make_issue(SEC_AWS, no, "Looks like an AWS access key ID.",
                                  "Revoke the key, remove it from history, and use IAM roles or a secret store."))
        if _PRIV_RE.search(text):
            out.append(make_issue(SEC_PRIVKEY, no, "A private key is committed to the repository.",
                                  "Remove it from history, rotate the key, and load keys from a secret store."))
        if _GH_RE.search(text):
            out.append(make_issue(SEC_GH, no, "Looks like a GitHub personal access token.",
                                  "Revoke it immediately and use `GITHUB_TOKEN`/secrets instead."))

        if _COMMENT_PREFIX.match(text):
            if _TODO_RE.search(text):
                out.append(make_issue(MNT_TODO, no, "Unresolved TODO/FIXME marker.",
                                      "Resolve it or link it to a tracked issue."))
            continue

        if is_js:
            code = _strip_js_strings(text)
            if _JS_EVAL_RE.search(code):
                out.append(make_issue(JS_EVAL, no, "`eval`/`new Function` executes strings as code.",
                                      "Parse data with `JSON.parse`; avoid dynamic code generation."))
            if _JS_HTML_RE.search(text):
                out.append(make_issue(JS_HTML, no, "Assigning HTML from a string can introduce cross-site scripting.",
                                      "Use `textContent`, or sanitise with DOMPurify before inserting HTML."))
            if _JS_EXEC_RE.search(text):
                out.append(make_issue(JS_EXEC, no, "A shell command is built from dynamic values.",
                                      "Use `execFile`/`spawn` with an argument array."))
            if _JS_LOG_RE.search(code):
                out.append(make_issue(JS_LOG, no, "`console.log` left in code.", "Remove it or use a real logger."))
            if _JS_EQ_RE.search(code):
                out.append(make_issue(JS_EQ, no, "Loose equality performs type coercion (`0 == ''` is true).",
                                      "Use `===` / `!==`."))

        tail = re.search(r"(#|//)\s*(TODO|FIXME|HACK|XXX)\b", text)
        if tail:
            out.append(make_issue(MNT_TODO, no, "Unresolved TODO/FIXME marker.", "Resolve it or link it to a tracked issue."))
    return out
