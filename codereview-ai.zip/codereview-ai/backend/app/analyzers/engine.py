import ast
import textwrap
from dataclasses import dataclass, replace

from .base import Issue
from .patterns import analyze_lines
from .python_ast import analyze_python

SUPPORTED_EXTENSIONS = (".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".java", ".go", ".rb", ".php", ".cs", ".c", ".cpp", ".rs", ".sh", ".yml", ".yaml", ".env", ".txt", ".md", ".json", ".toml", ".ini", ".cfg")


@dataclass
class SourceFile:
    path: str
    content: str
    # None = report on the whole file; otherwise only on these (new-side) line numbers.
    changed_lines: set[int] | None = None
    # For diff-only reviews we have just the added lines, not the whole file.
    sparse_lines: dict[int, str] | None = None

    def line_text(self, n: int) -> str:
        if self.sparse_lines is not None:
            return self.sparse_lines.get(n, "")
        lines = self.content.splitlines()
        return lines[n - 1] if 0 < n <= len(lines) else ""


def is_supported(path: str) -> bool:
    return path.lower().endswith(SUPPORTED_EXTENSIONS)


def _parses(text: str) -> bool:
    try:
        ast.parse(text)
        return True
    except SyntaxError:
        return False


def _python_fragment_issues(lines: dict[int, str]) -> list[Issue]:
    """Diff-only mode: run the AST rules on runs of consecutive added lines.
    A run that doesn't parse on its own is retried line by line; lines that still
    don't parse (e.g. a bare `else:`) are skipped rather than reported as syntax errors."""
    runs: list[list[int]] = []
    for n in sorted(lines):
        if runs and n == runs[-1][-1] + 1:
            runs[-1].append(n)
        else:
            runs.append([n])
    issues: list[Issue] = []
    for run in runs:
        text = lambda group: textwrap.dedent("\n".join(lines[n] for n in group))
        groups = [run] if _parses(text(run)) else [[n] for n in run]
        for group in groups:
            if _parses(text(group)):
                offset = group[0] - 1
                issues += [replace(i, line=i.line + offset) for i in analyze_python(text(group))]
    return issues


def analyze_file(f: SourceFile) -> list[Issue]:
    if f.sparse_lines is not None:
        issues = analyze_lines(f.path, f.sparse_lines)
        if f.path.lower().endswith(".py"):
            issues += _python_fragment_issues(f.sparse_lines)
    else:
        lines = {i: t for i, t in enumerate(f.content.splitlines(), start=1)}
        issues = analyze_lines(f.path, lines)
        if f.path.lower().endswith(".py"):
            issues += analyze_python(f.content)

    if f.changed_lines is not None:
        issues = [i for i in issues if i.line in f.changed_lines]

    # De-duplicate identical findings and order for stable output.
    unique = {(i.rule_id, i.line, i.message): i for i in issues}
    return sorted(unique.values(), key=lambda i: (i.line, i.rule_id))
