"""AST-based checks for Python. Precise line numbers, far fewer false positives than regex."""
import ast

from .base import Issue, make_issue, rule

PY_SYNTAX = rule("PY000", "low", "bug", "File does not parse")
PY_EVAL = rule("PY001", "high", "security", "eval()/exec() on dynamic input")
PY_SHELL = rule("PY002", "high", "security", "Shell command execution")
PY_DESER = rule("PY003", "high", "security", "Unsafe deserialization")
PY_HASH = rule("PY004", "medium", "security", "Weak hash algorithm")
PY_SQLI = rule("PY005", "high", "security", "SQL built with string formatting")
PY_TLS = rule("PY006", "high", "security", "TLS verification disabled")
PY_EXCEPT = rule("PY007", "medium", "bug", "Bare or swallowed exception")
PY_MUTDEF = rule("PY008", "medium", "bug", "Mutable default argument")
PY_LONGFN = rule("PY009", "low", "maintainability", "Function is too long")
PY_COMPLEX = rule("PY010", "medium", "maintainability", "High cyclomatic complexity")
PY_PARAMS = rule("PY011", "low", "maintainability", "Too many parameters")
PY_NONE = rule("PY012", "low", "bug", "Comparison to None with ==/!=")
PY_DEBUG = rule("PY013", "medium", "security", "Debug mode enabled")
PY_MKTEMP = rule("PY014", "medium", "security", "Insecure temp file (mktemp)")

MAX_FUNC_LINES = 50
MAX_COMPLEXITY = 10
MAX_PARAMS = 6

_EXEC_SQL = {"execute", "executemany", "executescript"}


def _call_name(node: ast.Call) -> str:
    """Dotted name of the callee, e.g. 'subprocess.run' or 'cursor.execute'."""
    parts: list[str] = []
    cur: ast.AST = node.func
    while isinstance(cur, ast.Attribute):
        parts.append(cur.attr)
        cur = cur.value
    if isinstance(cur, ast.Name):
        parts.append(cur.id)
    return ".".join(reversed(parts))


def _kw_is(node: ast.Call, name: str, value) -> bool:
    return any(
        k.arg == name and isinstance(k.value, ast.Constant) and k.value.value is value
        for k in node.keywords
    )


def _is_dynamic_string(node: ast.AST) -> bool:
    """True for f-strings with substitutions, 'a' + b, 'a %s' % b, 'a {}'.format(b)."""
    if isinstance(node, ast.JoinedStr):
        return any(isinstance(v, ast.FormattedValue) for v in node.values)
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Mod)):
        sides = (node.left, node.right)
        has_str = any(isinstance(s, ast.Constant) and isinstance(s.value, str) for s in sides)
        all_const = all(isinstance(s, ast.Constant) for s in sides)
        return has_str and not all_const
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "format":
        return isinstance(node.func.value, ast.Constant) and isinstance(node.func.value.value, str)
    return False


def _complexity(fn: ast.AST) -> int:
    score = 1
    for n in ast.walk(fn):
        if n is fn:
            continue
        if isinstance(n, (ast.If, ast.For, ast.AsyncFor, ast.While, ast.ExceptHandler, ast.IfExp, ast.comprehension)):
            score += 1
        elif isinstance(n, ast.BoolOp):
            score += len(n.values) - 1
        elif isinstance(n, ast.match_case):
            score += 1
    return score


def _check_call(node: ast.Call, out: list[Issue]) -> None:
    name = _call_name(node)

    if name in ("eval", "exec") and node.args and not isinstance(node.args[0], ast.Constant):
        out.append(make_issue(PY_EVAL, node.lineno,
                              f"`{name}()` runs arbitrary code; if any part of the input is user-controlled this is remote code execution.",
                              "Use `ast.literal_eval` for data, or a dispatch table of allowed operations."))

    if name == "os.system" or name.startswith("os.popen"):
        out.append(make_issue(PY_SHELL, node.lineno,
                              f"`{name}` runs through a shell, so metacharacters in arguments are interpreted.",
                              "Use `subprocess.run([...], shell=False)` with an argument list."))
    elif name.startswith("subprocess.") and _kw_is(node, "shell", True):
        sev_note = "with a non-literal command" if node.args and not isinstance(node.args[0], ast.Constant) else ""
        out.append(make_issue(PY_SHELL, node.lineno,
                              f"`{name}(..., shell=True)` {sev_note} allows shell injection.".replace("  ", " "),
                              "Pass the command as a list and drop `shell=True`; use `shlex.quote` if a shell is unavoidable."))

    if name in ("pickle.load", "pickle.loads", "cPickle.load", "cPickle.loads", "marshal.load", "marshal.loads", "shelve.open"):
        out.append(make_issue(PY_DESER, node.lineno,
                              f"`{name}` can execute arbitrary code when given untrusted data.",
                              "Use JSON (or another data-only format) for anything that crosses a trust boundary."))
    if name == "yaml.load" and not any(k.arg == "Loader" and "Safe" in ast.unparse(k.value) for k in node.keywords):
        out.append(make_issue(PY_DESER, node.lineno,
                              "`yaml.load` without a safe loader can construct arbitrary Python objects.",
                              "Use `yaml.safe_load(...)`."))

    if name in ("hashlib.md5", "hashlib.sha1"):
        out.append(make_issue(PY_HASH, node.lineno,
                              f"`{name}` is cryptographically broken; unsuitable for passwords, signatures or integrity checks.",
                              "Use SHA-256+ for integrity; use `hashlib.scrypt`/bcrypt/argon2 for passwords."))

    if name.split(".")[-1] in _EXEC_SQL and node.args and _is_dynamic_string(node.args[0]):
        out.append(make_issue(PY_SQLI, node.lineno,
                              "SQL query is assembled with string formatting/concatenation, which enables SQL injection.",
                              "Use parameterised queries: `cursor.execute('... WHERE id = %s', (value,))`."))

    if name.startswith(("requests.", "httpx.")) and _kw_is(node, "verify", False):
        out.append(make_issue(PY_TLS, node.lineno,
                              "`verify=False` disables certificate validation and allows man-in-the-middle attacks.",
                              "Remove it, or point `verify` at a CA bundle for private CAs."))

    if name.endswith(".run") and _kw_is(node, "debug", True):
        out.append(make_issue(PY_DEBUG, node.lineno,
                              "`debug=True` exposes an interactive debugger/stack traces; never ship it.",
                              "Read the flag from configuration and default it to False."))

    if name == "tempfile.mktemp":
        out.append(make_issue(PY_MKTEMP, node.lineno,
                              "`tempfile.mktemp` is racy: another process can create the file between name generation and use.",
                              "Use `tempfile.NamedTemporaryFile` or `tempfile.mkstemp`."))


def _check_function(fn: ast.FunctionDef | ast.AsyncFunctionDef, out: list[Issue]) -> None:
    for default in [*fn.args.defaults, *[d for d in fn.args.kw_defaults if d is not None]]:
        if isinstance(default, (ast.List, ast.Dict, ast.Set)) or (
            isinstance(default, ast.Call) and _call_name(default) in ("list", "dict", "set")
        ):
            out.append(make_issue(PY_MUTDEF, default.lineno,
                                  f"Mutable default argument in `{fn.name}` is shared between calls.",
                                  "Default to `None` and create the object inside the function."))

    length = (fn.end_lineno or fn.lineno) - fn.lineno + 1
    if length > MAX_FUNC_LINES:
        out.append(make_issue(PY_LONGFN, fn.lineno,
                              f"`{fn.name}` is {length} lines long (limit {MAX_FUNC_LINES}).",
                              "Split it into smaller functions with a single responsibility each."))

    score = _complexity(fn)
    if score > MAX_COMPLEXITY:
        out.append(make_issue(PY_COMPLEX, fn.lineno,
                              f"`{fn.name}` has cyclomatic complexity {score} (limit {MAX_COMPLEXITY}); hard to test and reason about.",
                              "Extract branches into helpers, use early returns or lookup tables."))

    a = fn.args
    n_params = len(a.posonlyargs) + len(a.args) + len(a.kwonlyargs)
    if n_params and a.args and a.args[0].arg in ("self", "cls"):
        n_params -= 1
    if n_params > MAX_PARAMS:
        out.append(make_issue(PY_PARAMS, fn.lineno,
                              f"`{fn.name}` takes {n_params} parameters (limit {MAX_PARAMS}).",
                              "Group related parameters into a dataclass or config object."))


def _check_handler(h: ast.ExceptHandler, out: list[Issue]) -> None:
    broad = h.type is None or (isinstance(h.type, ast.Name) and h.type.id in ("Exception", "BaseException"))
    swallowed = len(h.body) == 1 and isinstance(h.body[0], (ast.Pass, ast.Continue))
    if h.type is None:
        out.append(make_issue(PY_EXCEPT, h.lineno,
                              "Bare `except:` also catches KeyboardInterrupt/SystemExit and hides real bugs.",
                              "Catch the specific exceptions you can handle."))
    elif broad and swallowed:
        out.append(make_issue(PY_EXCEPT, h.lineno,
                              "Broad exception is silently swallowed; failures will go unnoticed.",
                              "Catch specific exceptions and at least log the error."))


def analyze_python(source: str) -> list[Issue]:
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        return [make_issue(PY_SYNTAX, e.lineno or 1, f"File could not be parsed: {e.msg}.")]

    out: list[Issue] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            _check_call(node, out)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            _check_function(node, out)
        elif isinstance(node, ast.ExceptHandler):
            _check_handler(node, out)
        elif isinstance(node, ast.Compare):
            for op, comp in zip(node.ops, node.comparators):
                if isinstance(op, (ast.Eq, ast.NotEq)) and isinstance(comp, ast.Constant) and comp.value is None:
                    out.append(make_issue(PY_NONE, node.lineno,
                                          "Use `is None` / `is not None`; `==` can be overridden and give wrong results.",
                                          "Replace `== None` with `is None`."))
    return out
