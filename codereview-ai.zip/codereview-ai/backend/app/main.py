import hashlib
import hmac
import json
import logging
from collections import defaultdict
from contextlib import asynccontextmanager

from fastapi import APIRouter, BackgroundTasks, Depends, FastAPI, Header, HTTPException, Query, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .analyzers.base import RULES
from .analyzers.engine import SourceFile, is_supported
from .config import settings
from .database import Base, SessionLocal, engine, get_db
from .diffparse import parse_patch, parse_unified_diff
from .github_client import GitHubClient, GitHubError, valid_repo
from .llm import LLMReviewer, get_llm
from .models import Finding, Review
from .review_service import format_github_comment, run_review
from .schemas import (DiffIn, FindingOut, FindingTriage, PullRequestIn, ReviewDetail, ReviewOut, RuleStat, SnippetIn)

log = logging.getLogger("codereview")
MAX_COMMENTS_PER_REVIEW = 30


@asynccontextmanager
async def lifespan(_app: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(title="CodeReview AI", version="1.0.0", lifespan=lifespan,
              description="Automated code review: static analysis + optional LLM pass, GitHub PR integration, false-positive tracking.")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()],
    allow_methods=["GET", "POST", "PATCH", "DELETE"],
    allow_headers=["Content-Type", "X-API-Key"],
)


# ---------------------------------------------------------------- dependencies
def require_api_key(x_api_key: str | None = Header(default=None)) -> None:
    if not settings.api_key:
        return  # open mode for local development
    if not x_api_key or not hmac.compare_digest(x_api_key, settings.api_key):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or missing X-API-Key")


def get_github() -> GitHubClient:
    return GitHubClient()


def get_session_factory():
    return SessionLocal


api = APIRouter(dependencies=[Depends(require_api_key)])


# --------------------------------------------------------------------- helpers
def _counts(db: Session, review_ids: list[int]) -> dict[int, dict[str, int]]:
    """Open + confirmed findings per severity (false positives don't count against a review)."""
    result: dict[int, dict[str, int]] = defaultdict(lambda: {"high": 0, "medium": 0, "low": 0})
    if review_ids:
        rows = db.execute(
            select(Finding.review_id, Finding.severity, func.count())
            .where(Finding.review_id.in_(review_ids), Finding.status != "false_positive")
            .group_by(Finding.review_id, Finding.severity)
        ).all()
        for rid, sev, n in rows:
            result[rid][sev] = n
    return result


def _review_out(review: Review, counts: dict[str, int]) -> ReviewOut:
    out = ReviewOut.model_validate(review)
    out.counts = counts
    return out


def _detail(db: Session, review: Review, comments_posted: bool = False) -> ReviewDetail:
    base = _review_out(review, _counts(db, [review.id])[review.id])
    return ReviewDetail(**base.model_dump(), findings=[FindingOut.model_validate(f) for f in review.findings],
                        comments_posted=comments_posted)


def _github_error(e: GitHubError) -> HTTPException:
    code = status.HTTP_404_NOT_FOUND if e.status == 404 else status.HTTP_502_BAD_GATEWAY
    return HTTPException(code, e.message)


def review_pull_request(db: Session, gh: GitHubClient, llm: LLMReviewer | None, repo: str, number: int,
                        post_comments: bool) -> tuple[Review, bool]:
    pr = gh.get_pull_request(repo, number)
    files: list[SourceFile] = []
    for f in gh.list_pull_files(repo, number):
        path, patch = f.get("filename", ""), f.get("patch")
        if f.get("status") == "removed" or not patch or not is_supported(path):
            continue
        added = parse_patch(patch)
        if not added:
            continue
        content = gh.get_file_content(repo, path, pr["head_sha"])
        if content is None or len(content.encode()) > settings.max_file_bytes:
            continue
        files.append(SourceFile(path, content, changed_lines=set(added)))
        if len(files) >= settings.max_files_per_review:
            break

    review = run_review(db, files=files, source="pull_request", title=pr["title"], repo=repo,
                        pr_number=number, head_sha=pr["head_sha"], llm=llm)

    posted = False
    if post_comments:
        open_findings = [f for f in review.findings if f.status == "open"][:MAX_COMMENTS_PER_REVIEW]
        if open_findings:
            try:
                gh.post_review(
                    repo, number, pr["head_sha"],
                    body=f"CodeReview AI found {len(open_findings)} issue(s) in the changed lines.",
                    comments=[{"path": f.file_path, "line": f.line, "side": "RIGHT",
                               "body": format_github_comment(f)} for f in open_findings],
                )
                posted = True
            except GitHubError as e:
                log.warning("could not post review comments: %s", e.message)
    return review, posted


# -------------------------------------------------------------------- routes
@app.get("/health", tags=["meta"])
def health():
    return {"status": "ok"}


@api.get("/rules", tags=["meta"])
def list_rules():
    return [{"rule_id": rid, "severity": s, "category": c, "title": t} for rid, (s, c, t) in sorted(RULES.items())]


@api.post("/reviews/snippet", response_model=ReviewDetail, status_code=201, tags=["reviews"])
def review_snippet(payload: SnippetIn, db: Session = Depends(get_db), llm: LLMReviewer | None = Depends(get_llm)):
    if len(payload.code.encode()) > settings.max_snippet_bytes:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "Code is too large")
    review = run_review(db, files=[SourceFile(payload.filename, payload.code)], source="snippet",
                        title=payload.filename, llm=llm if payload.use_llm else None)
    return _detail(db, review)


@api.post("/reviews/diff", response_model=ReviewDetail, status_code=201, tags=["reviews"])
def review_diff(payload: DiffIn, db: Session = Depends(get_db)):
    """Review a pasted unified diff. Only added lines are checked (line-based rules)."""
    parsed = parse_unified_diff(payload.diff)
    files = [SourceFile(p, "", changed_lines=set(lines), sparse_lines=lines)
             for p, lines in parsed.items() if lines and is_supported(p)][: settings.max_files_per_review]
    if not files:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "No reviewable added lines found in diff")
    return _detail(db, run_review(db, files=files, source="diff", title="Pasted diff"))


@api.post("/reviews/pull-request", response_model=ReviewDetail, status_code=201, tags=["reviews"])
def review_pr(payload: PullRequestIn, db: Session = Depends(get_db), gh: GitHubClient = Depends(get_github),
              llm: LLMReviewer | None = Depends(get_llm)):
    try:
        review, posted = review_pull_request(db, gh, llm if payload.use_llm else None, payload.repo,
                                             payload.pr_number, payload.post_comments)
    except GitHubError as e:
        raise _github_error(e)
    return _detail(db, review, comments_posted=posted)


@api.get("/reviews", response_model=list[ReviewOut], tags=["reviews"])
def list_reviews(limit: int = Query(20, ge=1, le=100), offset: int = Query(0, ge=0), db: Session = Depends(get_db)):
    reviews = db.scalars(select(Review).order_by(Review.id.desc()).limit(limit).offset(offset)).all()
    counts = _counts(db, [r.id for r in reviews])
    return [_review_out(r, counts[r.id]) for r in reviews]


@api.get("/reviews/{review_id}", response_model=ReviewDetail, tags=["reviews"])
def get_review(review_id: int, db: Session = Depends(get_db)):
    review = db.get(Review, review_id)
    if review is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Review not found")
    return _detail(db, review)


@api.delete("/reviews/{review_id}", status_code=204, tags=["reviews"])
def delete_review(review_id: int, db: Session = Depends(get_db)):
    review = db.get(Review, review_id)
    if review is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Review not found")
    db.delete(review)
    db.commit()
    return Response(status_code=204)


@api.patch("/findings/{finding_id}", response_model=FindingOut, tags=["findings"])
def triage_finding(finding_id: int, payload: FindingTriage, db: Session = Depends(get_db)):
    """Mark a finding as confirmed or a false positive. A false positive suppresses the same
    finding (same rule, file and line text) in all future reviews."""
    finding = db.get(Finding, finding_id)
    if finding is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Finding not found")
    finding.status = payload.status
    if payload.status != "false_positive":
        finding.auto_suppressed = False
    db.commit()
    return finding


@api.get("/stats/rules", response_model=list[RuleStat], tags=["findings"])
def rule_stats(db: Session = Depends(get_db)):
    """Per-rule precision tracking: which rules produce false positives?"""
    rows = db.execute(
        select(Finding.rule_id, Finding.status, func.count()).group_by(Finding.rule_id, Finding.status)
    ).all()
    agg: dict[str, dict[str, int]] = defaultdict(lambda: {"open": 0, "confirmed": 0, "false_positive": 0})
    for rule_id, st, n in rows:
        agg[rule_id][st] = n
    stats = []
    for rule_id, c in agg.items():
        triaged = c["confirmed"] + c["false_positive"]
        stats.append(RuleStat(
            rule_id=rule_id, title=RULES.get(rule_id, ("", "", "LLM-generated finding"))[2],
            total=sum(c.values()), open=c["open"], confirmed=c["confirmed"], false_positive=c["false_positive"],
            false_positive_rate=round(c["false_positive"] / triaged, 3) if triaged else None,
        ))
    return sorted(stats, key=lambda s: (-(s.false_positive_rate or 0), -s.total))


# ---------------------------------------------------------------- webhook
def verify_signature(secret: str, body: bytes, header: str | None) -> bool:
    if not secret or not header or not header.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header)  # constant-time comparison


def _review_in_background(session_factory, gh: GitHubClient, llm, repo: str, number: int) -> None:
    db = session_factory()
    try:
        review_pull_request(db, gh, llm, repo, number, post_comments=True)
    except Exception:  # background task: log, never crash the worker
        log.exception("webhook review failed for %s#%s", repo, number)
    finally:
        db.close()


@app.post("/webhooks/github", tags=["github"], status_code=202)
async def github_webhook(
    request: Request,
    background: BackgroundTasks,
    x_hub_signature_256: str | None = Header(default=None),
    x_github_event: str | None = Header(default=None),
    gh: GitHubClient = Depends(get_github),
    llm: LLMReviewer | None = Depends(get_llm),
    session_factory=Depends(get_session_factory),
):
    """GitHub `pull_request` webhook. Requests must carry a valid HMAC signature."""
    body = await request.body()
    if not settings.github_webhook_secret:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Webhook secret is not configured")
    if not verify_signature(settings.github_webhook_secret, body, x_hub_signature_256):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid signature")

    if x_github_event == "ping":
        return {"status": "pong"}
    if x_github_event != "pull_request":
        return {"status": "ignored"}
    try:
        payload = json.loads(body)
        action = payload["action"]
        repo = payload["repository"]["full_name"]
        number = int(payload["pull_request"]["number"])
    except (ValueError, KeyError, TypeError):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Malformed payload")
    if action not in ("opened", "synchronize", "reopened") or not valid_repo(repo):
        return {"status": "ignored"}

    background.add_task(_review_in_background, session_factory, gh, llm, repo, number)
    return {"status": "queued"}


app.include_router(api)
