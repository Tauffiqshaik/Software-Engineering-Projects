"""Parse unified diffs into {new-side line number: text} for added lines."""
import re

_HUNK = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@")


def parse_patch(patch: str) -> dict[int, str]:
    """Added lines of one file's patch, keyed by their line number in the new file."""
    added: dict[int, str] = {}
    new_line = 0
    in_hunk = False
    for raw in patch.splitlines():
        m = _HUNK.match(raw)
        if m:
            new_line = int(m.group(1))
            in_hunk = True
            continue
        if not in_hunk or raw.startswith("\\"):  # "\ No newline at end of file"
            continue
        if raw.startswith("+"):
            added[new_line] = raw[1:]
            new_line += 1
        elif raw.startswith("-"):
            continue
        else:  # context line
            new_line += 1
    return added


def parse_unified_diff(diff: str) -> dict[str, dict[int, str]]:
    """Split a multi-file `git diff` into {path: added_lines}. Deleted files are skipped."""
    files: dict[str, dict[int, str]] = {}
    path: str | None = None
    chunk: list[str] = []

    def flush():
        if path is not None:
            files[path] = parse_patch("\n".join(chunk))

    for line in diff.splitlines():
        if line.startswith("diff --git "):
            flush()
            path, chunk = None, []
        elif line.startswith("+++ ") and not chunk:  # inside a hunk, "+++ x" is an added line
            target = line[4:].strip()
            path = None if target == "/dev/null" else (target[2:] if target.startswith("b/") else target)
        elif path is not None or line.startswith("@@"):
            chunk.append(line)
    flush()
    return files
