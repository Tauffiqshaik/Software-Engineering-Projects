"""Minimal GitHub REST client (pull requests, file contents, posting reviews)."""
import re
from urllib.parse import quote

import httpx

from .config import settings

API = "https://api.github.com"
REPO_RE = re.compile(r"^[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}$")
MAX_PR_FILES = 300  # GitHub's own cap for the pull-request files endpoint


class GitHubError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def valid_repo(repo: str) -> bool:
    """owner/name, restricted to GitHub's allowed characters (also blocks path tricks like '../')."""
    return bool(REPO_RE.match(repo)) and not any(p in (".", "..") for p in repo.split("/"))


class GitHubClient:
    def __init__(self, token: str | None = None, transport: httpx.BaseTransport | None = None):
        headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "codereview-ai",
        }
        token = token if token is not None else settings.github_token
        if token:
            headers["Authorization"] = f"Bearer {token}"
        self._http = httpx.Client(base_url=API, headers=headers, timeout=15, transport=transport)

    def _request(self, method: str, url: str, **kw) -> httpx.Response:
        try:
            resp = self._http.request(method, url, **kw)
        except httpx.HTTPError as e:
            raise GitHubError(502, f"Could not reach GitHub: {type(e).__name__}") from e
        if resp.status_code >= 400:
            # Never echo the response body verbatim; it can contain request details.
            reason = {401: "GitHub rejected the token", 403: "GitHub denied access or rate-limited the request",
                      404: "Not found (check the repo/PR, and that the token can read it)"}.get(
                resp.status_code, f"GitHub returned HTTP {resp.status_code}")
            raise GitHubError(resp.status_code, reason)
        return resp

    def get_pull_request(self, repo: str, number: int) -> dict:
        data = self._request("GET", f"/repos/{repo}/pulls/{number}").json()
        return {"title": data.get("title", ""), "head_sha": data["head"]["sha"], "state": data.get("state", "")}

    def list_pull_files(self, repo: str, number: int) -> list[dict]:
        files: list[dict] = []
        page = 1
        while len(files) < MAX_PR_FILES:
            batch = self._request(
                "GET", f"/repos/{repo}/pulls/{number}/files", params={"per_page": 100, "page": page}
            ).json()
            files.extend(batch)
            if len(batch) < 100:
                break
            page += 1
        return files

    def get_file_content(self, repo: str, path: str, ref: str) -> str | None:
        """Raw file text at `ref`, or None if it is missing or not UTF-8 text."""
        try:
            resp = self._request(
                "GET", f"/repos/{repo}/contents/{quote(path)}", params={"ref": ref},
                headers={"Accept": "application/vnd.github.raw+json"},
            )
        except GitHubError as e:
            if e.status == 404:
                return None
            raise
        try:
            return resp.content.decode("utf-8")
        except UnicodeDecodeError:
            return None

    def post_review(self, repo: str, number: int, commit_id: str, body: str, comments: list[dict]) -> None:
        self._request(
            "POST", f"/repos/{repo}/pulls/{number}/reviews",
            json={"commit_id": commit_id, "body": body, "event": "COMMENT", "comments": comments},
        )
