from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .github_client import valid_repo


class SnippetIn(BaseModel):
    filename: str = Field(min_length=1, max_length=255, description="Used to pick language rules, e.g. app.py")
    code: str = Field(min_length=1, max_length=200_000)
    use_llm: bool = True

    @field_validator("filename")
    @classmethod
    def _no_traversal(cls, v: str) -> str:
        if v.startswith("/") or ".." in v.split("/") or "\\" in v or "\x00" in v:
            raise ValueError("invalid filename")
        return v


class DiffIn(BaseModel):
    diff: str = Field(min_length=1, max_length=1_000_000, description="Unified diff, e.g. `git diff` output")


class PullRequestIn(BaseModel):
    repo: str = Field(description="owner/name", examples=["octocat/hello-world"])
    pr_number: int = Field(ge=1, le=10_000_000)
    use_llm: bool = True
    post_comments: bool = Field(False, description="Post the findings back to the PR as a review")

    @field_validator("repo")
    @classmethod
    def _repo_format(cls, v: str) -> str:
        if not valid_repo(v):
            raise ValueError("repo must look like 'owner/name'")
        return v


class FindingOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    review_id: int
    file_path: str
    line: int
    rule_id: str
    severity: str
    category: str
    source: str
    message: str
    suggestion: str
    code_line: str
    status: str
    auto_suppressed: bool


class ReviewOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    source: str
    repo: str | None
    pr_number: int | None
    head_sha: str | None
    title: str
    status: str
    files_reviewed: int
    llm_used: bool
    created_at: datetime
    counts: dict[str, int] = {}


class ReviewDetail(ReviewOut):
    findings: list[FindingOut]
    comments_posted: bool = False


class FindingTriage(BaseModel):
    status: Literal["open", "confirmed", "false_positive"]


class RuleStat(BaseModel):
    rule_id: str
    title: str
    total: int
    open: int
    confirmed: int
    false_positive: int
    false_positive_rate: float | None  # fp / (fp + confirmed); None until something is triaged
