import pytest

from app.config import settings
from app.github_client import GitHubError

BAD_CODE = """import os
password = "hunter2hunter2"
def f(x=[]):
    cur.execute(f"SELECT * FROM t WHERE id={x}")
    return eval(x)
"""


def snippet(client, code=BAD_CODE, filename="app.py"):
    r = client.post("/reviews/snippet", json={"filename": filename, "code": code, "use_llm": False})
    assert r.status_code == 201, r.text
    return r.json()


# ------------------------------------------------------------------- snippets
def test_snippet_review_has_line_references_and_sorted_by_severity(client):
    review = snippet(client)
    got = [(f["rule_id"], f["line"], f["severity"]) for f in review["findings"]]
    assert ("SEC001", 2, "high") in got and ("PY005", 4, "high") in got and ("PY008", 3, "medium") in got
    sev = [f["severity"] for f in review["findings"]]
    assert sev == sorted(sev, key=["high", "medium", "low"].index)
    assert review["counts"]["high"] >= 3
    assert all(f["code_line"] and f["suggestion"] for f in review["findings"])


def test_clean_code_has_no_findings(client):
    review = snippet(client, "def add(a, b):\n    return a + b\n")
    assert review["findings"] == [] and review["counts"] == {"high": 0, "medium": 0, "low": 0}


@pytest.mark.parametrize(
    "body",
    [
        {"filename": "a.py"},
        {"code": "x=1"},
        {"filename": "", "code": "x=1"},
        {"filename": "a.py", "code": ""},
        {"filename": "../../etc/passwd", "code": "x=1"},
        {"filename": "/etc/passwd", "code": "x=1"},
        {"filename": "a\\b.py", "code": "x=1"},
        {"filename": "a.py", "code": "x" * 200_001},
        {"filename": "a.py", "code": 123},
    ],
)
def test_invalid_snippet_rejected(client, body):
    assert client.post("/reviews/snippet", json=body).status_code == 422


# ----------------------------------------------------------------------- diff
def test_diff_review_only_flags_added_lines(client):
    diff = """diff --git a/a.py b/a.py
--- a/a.py
+++ b/a.py
@@ -1,3 +1,4 @@
 token = "oldoldoldold1"
+password = "hunter2hunter2"
 x = 1
"""
    r = client.post("/reviews/diff", json={"diff": diff})
    assert r.status_code == 201
    findings = r.json()["findings"]
    assert [(f["rule_id"], f["line"]) for f in findings] == [("SEC001", 2)]  # context line 1 ignored


def test_diff_without_reviewable_lines_is_422(client):
    assert client.post("/reviews/diff", json={"diff": "garbage"}).status_code == 422
    assert client.post("/reviews/diff", json={"diff": ""}).status_code == 422


# ---------------------------------------------------------------- pull requests
def _setup_pr(gh, content=BAD_CODE, patch=None):
    n = len(content.splitlines())
    gh.files = [{"filename": "src/app.py", "status": "added", "patch": patch or f"@@ -0,0 +1,{n} @@\n" + "\n".join("+" + l for l in content.splitlines())}]
    gh.contents = {"src/app.py": content}


def test_pull_request_review_and_posting(client, gh):
    _setup_pr(gh)
    r = client.post("/reviews/pull-request", json={"repo": "octo/repo", "pr_number": 7, "use_llm": False, "post_comments": True})
    assert r.status_code == 201, r.text
    body = r.json()
    assert (body["repo"], body["pr_number"], body["head_sha"], body["source"]) == ("octo/repo", 7, "abc123", "pull_request")
    assert body["comments_posted"] is True and len(gh.posted) == 1
    posted = gh.posted[0]
    assert posted["commit_id"] == "abc123"
    assert all(c["side"] == "RIGHT" and c["path"] == "src/app.py" and c["line"] >= 1 for c in posted["comments"])
    assert any("SEC001" in c["body"] for c in posted["comments"])


def test_pr_review_without_post_comments_does_not_post(client, gh):
    _setup_pr(gh)
    r = client.post("/reviews/pull-request", json={"repo": "octo/repo", "pr_number": 7, "use_llm": False})
    assert r.json()["comments_posted"] is False and gh.posted == []


def test_pr_only_reports_lines_changed_in_the_pr(client, gh):
    content = 'a = eval(x)\nb = eval(y)\nc = eval(z)\n'
    gh.files = [{"filename": "a.py", "status": "modified", "patch": "@@ -1,2 +1,3 @@\n a = eval(x)\n+b = eval(y)\n c = eval(z)"}]
    gh.contents = {"a.py": content}
    r = client.post("/reviews/pull-request", json={"repo": "o/r", "pr_number": 1, "use_llm": False})
    assert [f["line"] for f in r.json()["findings"]] == [2]


def test_pr_skips_removed_binary_unsupported_and_missing_files(client, gh):
    patch = "@@ -0,0 +1,1 @@\n+x = eval(y)"
    gh.files = [
        {"filename": "gone.py", "status": "removed", "patch": patch},
        {"filename": "img.png", "status": "added", "patch": patch},
        {"filename": "nopatch.py", "status": "added"},
        {"filename": "missing.py", "status": "added", "patch": patch},
    ]
    gh.contents = {}  # nothing fetchable
    r = client.post("/reviews/pull-request", json={"repo": "o/r", "pr_number": 1, "use_llm": False})
    assert r.status_code == 201 and r.json()["findings"] == [] and r.json()["files_reviewed"] == 0


def test_pr_skips_oversized_files(client, gh, monkeypatch):
    monkeypatch.setattr(settings, "max_file_bytes", 10)
    _setup_pr(gh)
    r = client.post("/reviews/pull-request", json={"repo": "o/r", "pr_number": 1, "use_llm": False})
    assert r.json()["files_reviewed"] == 0


@pytest.mark.parametrize("repo", ["noslash", "a/b/c", "../etc", "a/..", "a b/c", "a/b;rm", "", "/x", "x/"])
def test_invalid_repo_rejected(client, repo):
    r = client.post("/reviews/pull-request", json={"repo": repo, "pr_number": 1})
    assert r.status_code == 422


@pytest.mark.parametrize("n", [0, -1, "abc", None])
def test_invalid_pr_number_rejected(client, n):
    assert client.post("/reviews/pull-request", json={"repo": "o/r", "pr_number": n}).status_code == 422


def test_github_errors_are_mapped(client, gh):
    gh.fail_with = GitHubError(404, "Not found")
    assert client.post("/reviews/pull-request", json={"repo": "o/r", "pr_number": 1}).status_code == 404
    gh.fail_with = GitHubError(403, "denied")
    assert client.post("/reviews/pull-request", json={"repo": "o/r", "pr_number": 1}).status_code == 502


def test_failure_posting_comments_does_not_lose_the_review(client, gh):
    _setup_pr(gh)
    gh.fail_post = True
    r = client.post("/reviews/pull-request", json={"repo": "o/r", "pr_number": 1, "use_llm": False, "post_comments": True})
    assert r.status_code == 201 and r.json()["comments_posted"] is False and r.json()["findings"]
    assert client.get(f"/reviews/{r.json()['id']}").status_code == 200


# --------------------------------------------------- false-positive tracking
def test_mark_false_positive_suppresses_future_findings(client):
    first = snippet(client)
    target = next(f for f in first["findings"] if f["rule_id"] == "PY005")
    r = client.patch(f"/findings/{target['id']}", json={"status": "false_positive"})
    assert r.status_code == 200 and r.json()["status"] == "false_positive"

    # Same code again, but shifted down by unrelated lines: still suppressed (fingerprint ignores line number).
    second = snippet(client, "# header\n# more\n" + BAD_CODE)
    again = next(f for f in second["findings"] if f["rule_id"] == "PY005")
    assert again["status"] == "false_positive" and again["auto_suppressed"] is True
    assert again["line"] == target["line"] + 2
    # Other findings are unaffected.
    sec = next(f for f in second["findings"] if f["rule_id"] == "SEC001")
    assert sec["status"] == "open"
    # Suppressed findings don't count towards the review's severity totals.
    assert second["counts"]["high"] == first["counts"]["high"] - 1


def test_false_positive_is_scoped_to_file_and_rule(client):
    first = snippet(client, filename="a.py")
    fid = next(f["id"] for f in first["findings"] if f["rule_id"] == "PY005")
    client.patch(f"/findings/{fid}", json={"status": "false_positive"})
    other_file = snippet(client, filename="b.py")
    assert next(f for f in other_file["findings"] if f["rule_id"] == "PY005")["status"] == "open"


def test_reopening_removes_suppression(client):
    first = snippet(client)
    fid = next(f["id"] for f in first["findings"] if f["rule_id"] == "PY005")
    client.patch(f"/findings/{fid}", json={"status": "false_positive"})
    client.patch(f"/findings/{fid}", json={"status": "open"})
    again = snippet(client)
    assert next(f for f in again["findings"] if f["rule_id"] == "PY005")["status"] == "open"


def test_triage_validation(client):
    first = snippet(client)
    fid = first["findings"][0]["id"]
    assert client.patch(f"/findings/{fid}", json={"status": "bogus"}).status_code == 422
    assert client.patch(f"/findings/{fid}", json={}).status_code == 422
    assert client.patch("/findings/99999", json={"status": "confirmed"}).status_code == 404


def test_rule_stats_report_false_positive_rate(client):
    review = snippet(client)
    by_rule = {f["rule_id"]: f["id"] for f in review["findings"]}
    client.patch(f"/findings/{by_rule['PY005']}", json={"status": "false_positive"})
    client.patch(f"/findings/{by_rule['SEC001']}", json={"status": "confirmed"})
    stats = {s["rule_id"]: s for s in client.get("/stats/rules").json()}
    assert stats["PY005"]["false_positive_rate"] == 1.0 and stats["PY005"]["false_positive"] == 1
    assert stats["SEC001"]["false_positive_rate"] == 0.0 and stats["SEC001"]["confirmed"] == 1
    assert stats["PY001"]["false_positive_rate"] is None  # nothing triaged yet
    assert client.get("/stats/rules").json()[0]["rule_id"] == "PY005"  # worst offenders first


def test_stats_empty(client):
    assert client.get("/stats/rules").json() == []


# ------------------------------------------------------------ reviews CRUD
def test_list_get_delete_reviews(client):
    a, b = snippet(client), snippet(client, "x = 1\n")
    listing = client.get("/reviews").json()
    assert [r["id"] for r in listing] == [b["id"], a["id"]]  # newest first
    assert "findings" not in listing[0]
    assert client.get("/reviews", params={"limit": 1}).json()[0]["id"] == b["id"]
    assert client.get("/reviews", params={"limit": 0}).status_code == 422
    assert client.get(f"/reviews/{a['id']}").json()["findings"]
    assert client.get("/reviews/9999").status_code == 404
    assert client.delete(f"/reviews/{a['id']}").status_code == 204
    assert client.get(f"/reviews/{a['id']}").status_code == 404
    assert client.delete(f"/reviews/{a['id']}").status_code == 404


def test_rules_endpoint(client):
    rules = client.get("/rules").json()
    assert {"PY005", "SEC001", "JS002"} <= {r["rule_id"] for r in rules}


# --------------------------------------------------------------------- auth
def test_api_key_protects_endpoints_but_not_health(client):
    settings.api_key = "s3cret-key"
    assert client.get("/reviews").status_code == 401
    assert client.get("/reviews", headers={"X-API-Key": "wrong"}).status_code == 401
    assert client.get("/reviews", headers={"X-API-Key": "s3cret-key"}).status_code == 200
    assert client.get("/health").status_code == 200


def test_python_diff_gets_ast_rules_on_added_lines(client):
    diff = """diff --git a/a.py b/a.py
--- a/a.py
+++ b/a.py
@@ -1,3 +1,8 @@
 import os
+x = eval(user)
+def f(a=[]):
+    cur.execute(f"SELECT {a}")
+    if a:
+        pass
+    else:
+        pass
 keep = 1
"""
    r = client.post("/reviews/diff", json={"diff": diff})
    got = sorted((f["rule_id"], f["line"]) for f in r.json()["findings"])
    assert got == [("PY001", 2), ("PY005", 4), ("PY008", 3)]  # `else:` fragment is skipped, not a syntax error
