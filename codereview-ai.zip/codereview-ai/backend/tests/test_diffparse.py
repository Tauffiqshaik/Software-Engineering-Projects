from app.diffparse import parse_patch, parse_unified_diff

PATCH = """@@ -1,4 +1,5 @@
 import os
-old = 1
+new = 1
+extra = 2
 keep = 3
@@ -20,3 +21,4 @@ def f():
     a = 1
+    b = eval(x)
     c = 3
\\ No newline at end of file
"""


def test_parse_patch_maps_new_side_line_numbers():
    assert parse_patch(PATCH) == {2: "new = 1", 3: "extra = 2", 22: "    b = eval(x)"}


def test_parse_patch_empty_and_garbage():
    assert parse_patch("") == {}
    assert parse_patch("not a diff at all\n+looks like an add") == {}  # no hunk header


def test_parse_unified_diff_multi_file():
    diff = """diff --git a/a.py b/a.py
index 111..222 100644
--- a/a.py
+++ b/a.py
@@ -1,2 +1,3 @@
 x = 1
+y = eval(z)
 w = 2
diff --git a/old.py b/old.py
deleted file mode 100644
--- a/old.py
+++ /dev/null
@@ -1,1 +0,0 @@
-gone = 1
diff --git a/new.js b/new.js
new file mode 100644
--- /dev/null
+++ b/new.js
@@ -0,0 +1,2 @@
+one
+two
"""
    assert parse_unified_diff(diff) == {"a.py": {2: "y = eval(z)"}, "new.js": {1: "one", 2: "two"}}


def test_added_line_that_looks_like_header_is_not_misparsed():
    diff = """diff --git a/a.txt b/a.txt
--- a/a.txt
+++ b/a.txt
@@ -1,1 +1,2 @@
 keep
+++ not a header, just an added line starting with ++
"""
    assert parse_unified_diff(diff) == {"a.txt": {2: "++ not a header, just an added line starting with ++"}}
