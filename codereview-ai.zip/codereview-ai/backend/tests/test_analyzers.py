import textwrap

import pytest

from app.analyzers.engine import SourceFile, analyze_file


def run(path: str, code: str, changed=None):
    return analyze_file(SourceFile(path, textwrap.dedent(code).lstrip("\n"), changed))


def rules(issues):
    return [i.rule_id for i in issues]


# --------------------------------------------------------------- python: security
@pytest.mark.parametrize(
    "code, rule",
    [
        ("x = eval(user_input)\n", "PY001"),
        ("exec(code_string)\n", "PY001"),
        ("import os\nos.system('ls ' + path)\n", "PY002"),
        ("import subprocess\nsubprocess.run(cmd, shell=True)\n", "PY002"),
        ("import pickle\npickle.loads(data)\n", "PY003"),
        ("import yaml\nyaml.load(f)\n", "PY003"),
        ("import hashlib\nhashlib.md5(b'x')\n", "PY004"),
        ("import hashlib\nhashlib.sha1(b'x')\n", "PY004"),
        ("cur.execute(f\"SELECT * FROM t WHERE id = {uid}\")\n", "PY005"),
        ("cur.execute('SELECT * FROM t WHERE id = ' + uid)\n", "PY005"),
        ("cur.execute('SELECT * FROM t WHERE id = %s' % uid)\n", "PY005"),
        ("cur.execute('SELECT * FROM t WHERE id = {}'.format(uid))\n", "PY005"),
        ("import requests\nrequests.get(url, verify=False)\n", "PY006"),
        ("app.run(debug=True)\n", "PY013"),
        ("import tempfile\ntempfile.mktemp()\n", "PY014"),
    ],
)
def test_python_security_rules_fire(code, rule):
    assert rule in rules(run("a.py", code))


@pytest.mark.parametrize(
    "code",
    [
        "x = eval('1 + 1')\n",  # constant argument
        "import subprocess\nsubprocess.run(['ls', '-l'])\n",
        "import yaml\nyaml.load(f, Loader=yaml.SafeLoader)\n",
        "import yaml\nyaml.safe_load(f)\n",
        "import hashlib\nhashlib.sha256(b'x')\n",
        "cur.execute('SELECT * FROM t WHERE id = %s', (uid,))\n",  # parameterised
        "cur.execute('SELECT 1')\n",
        "cur.execute(f'SELECT 1')\n",  # f-string without substitutions
        "import requests\nrequests.get(url, verify=True)\n",
        "app.run(debug=False)\n",
    ],
)
def test_python_safe_code_is_not_flagged(code):
    assert run("a.py", code) == []


def test_sql_injection_message_has_fix_and_line():
    (issue,) = run("db.py", "x = 1\ncur.execute(f'DELETE FROM t WHERE id={i}')\n")
    assert issue.rule_id == "PY005" and issue.line == 2
    assert "parameter" in issue.suggestion.lower()


# ---------------------------------------------------------- python: bugs/quality
def test_bare_except_and_swallowed_exception():
    code = """
    try:
        a()
    except:
        pass
    try:
        b()
    except Exception:
        pass
    try:
        c()
    except ValueError:
        pass
    try:
        d()
    except Exception as e:
        log(e)
    """
    issues = run("a.py", code)
    assert [(i.rule_id, i.line) for i in issues] == [("PY007", 3), ("PY007", 7)]


def test_mutable_default_argument():
    code = """
    def a(x=[]): pass
    def b(x={}): pass
    def c(x=list()): pass
    def d(x=None): pass
    def e(x=()): pass
    """
    assert [(i.rule_id, i.line) for i in run("a.py", code)] == [("PY008", 1), ("PY008", 2), ("PY008", 3)]


def test_long_function_and_complexity_and_params():
    body = "\n".join(f"    x{i} = {i}" for i in range(60))
    assert "PY009" in rules(run("a.py", f"def big():\n{body}\n"))

    branches = "\n".join(f"    if a == {i}:\n        return {i}" for i in range(12))
    issues = run("a.py", f"def f(a):\n{branches}\n")
    assert "PY010" in rules(issues)

    assert "PY011" in rules(run("a.py", "def f(a, b, c, d, e, f, g): pass\n"))
    assert "PY011" not in rules(run("a.py", "class A:\n    def m(self, a, b, c, d, e, f): pass\n"))  # self excluded


def test_none_comparison():
    assert "PY012" in rules(run("a.py", "if x == None:\n    pass\n"))
    assert "PY012" in rules(run("a.py", "if x != None:\n    pass\n"))
    assert "PY012" not in rules(run("a.py", "if x is None:\n    pass\n"))


def test_syntax_error_reported_not_raised():
    (issue,) = run("a.py", "def broken(:\n")
    assert issue.rule_id == "PY000" and issue.line == 1


# ------------------------------------------------------------------- secrets
@pytest.mark.parametrize(
    "line",
    [
        'password = "hunter2hunter2"',
        'API_KEY = "sk_live_abcdef123456"',
        "db_password: 'S3cretValue!'",
        'const authToken = "abcd1234efgh5678";',
    ],
)
def test_hardcoded_secrets_detected(line):
    assert "SEC001" in rules(run("config.txt", line + "\n"))


@pytest.mark.parametrize(
    "line",
    [
        'password = os.environ["DB_PASSWORD"]',
        'password = ""',
        'password = "short"',  # < 8 chars
        'password = "${DB_PASSWORD}"',
        'api_key = "<your-api-key>"',
        'token = "changeme"',
        'secret = "example-secret-value"',
        "username = 'administrator'",
    ],
)
def test_placeholders_and_env_lookups_not_flagged(line):
    assert "SEC001" not in rules(run("config.txt", line + "\n"))


def test_secret_value_is_never_echoed():
    (issue,) = run("a.py", 'password = "hunter2hunter2"\n')
    assert "hunter2" not in issue.message and "hunter2" not in issue.suggestion


def test_known_token_formats():
    assert "SEC002" in rules(run("a.txt", "key = AKIAIOSFODNN7EXAMPLE\n"))
    assert "SEC003" in rules(run("a.txt", "-----BEGIN RSA PRIVATE KEY-----\n"))
    assert "SEC004" in rules(run("a.txt", "t = ghp_" + "a" * 36 + "\n"))


# --------------------------------------------------------------- javascript
def test_javascript_rules():
    code = """
    eval(userInput);
    el.innerHTML = html;
    console.log("debug");
    if (a == b) {}
    exec("ls " + dir);
    """
    got = rules(run("app.js", code))
    assert {"JS001", "JS002", "JS003", "JS004", "JS005"} <= set(got)


def test_javascript_safe_code_and_strings_not_flagged():
    code = """
    if (a === b) {}
    const s = "use == carefully and eval( is bad";
    el.textContent = text;
    """
    assert run("app.js", code) == []


def test_js_rules_do_not_apply_to_python_files():
    assert run("a.py", "console.log('x')\n") == []


# --------------------------------------------------------------- todo markers
def test_todo_markers_in_comments_only():
    issues = run("a.py", "# TODO: fix\nx = 1  # FIXME later\ns = 'TODO in a string'\n")
    assert [(i.rule_id, i.line) for i in issues] == [("MNT001", 1), ("MNT001", 2)]


# -------------------------------------------------------- changed-line filter
def test_only_changed_lines_are_reported():
    code = "a = eval(x)\nb = eval(y)\nc = eval(z)\n"
    issues = run("a.py", code, changed={2})
    assert [i.line for i in issues] == [2]


def test_results_sorted_and_deduplicated():
    issues = run("a.py", "b = eval(y)\na = eval(x)\n")
    assert [i.line for i in issues] == [1, 2]


@pytest.mark.parametrize(
    "line, flagged",
    [
        ('exec("ls " + dir);', True),
        ("exec(`ls ${dir}`);", True),
        ("execSync(cmd + ' -l');", True),
        ('exec("ls -l");', False),
        ("execFile('ls', [dir]);", False),
    ],
)
def test_js_command_injection_detection(line, flagged):
    assert ("JS005" in rules(run("a.js", line + "\n"))) is flagged
