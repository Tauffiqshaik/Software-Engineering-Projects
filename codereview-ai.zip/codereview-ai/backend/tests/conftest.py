import os

os.environ["DATABASE_URL"] = "sqlite://"
os.environ["API_KEY"] = ""
os.environ["ANTHROPIC_API_KEY"] = ""
os.environ["GITHUB_TOKEN"] = ""
os.environ["GITHUB_WEBHOOK_SECRET"] = ""

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.config import settings
from app.database import Base, get_db
from app.github_client import GitHubError
from app.llm import get_llm
from app.main import app, get_github, get_session_factory


class FakeGitHub:
    """In-memory stand-in for GitHubClient."""

    def __init__(self):
        self.pr = {"title": "Add feature", "head_sha": "abc123", "state": "open"}
        self.files: list[dict] = []
        self.contents: dict[str, str] = {}
        self.posted: list[dict] = []
        self.fail_with: GitHubError | None = None
        self.fail_post = False

    def get_pull_request(self, repo, number):
        if self.fail_with:
            raise self.fail_with
        return self.pr

    def list_pull_files(self, repo, number):
        return self.files

    def get_file_content(self, repo, path, ref):
        return self.contents.get(path)

    def post_review(self, repo, number, commit_id, body, comments):
        if self.fail_post:
            raise GitHubError(403, "denied")
        self.posted.append({"repo": repo, "number": number, "commit_id": commit_id, "comments": comments})


@pytest.fixture()
def gh():
    return FakeGitHub()


@pytest.fixture()
def client(gh):
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

    def override_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_db
    app.dependency_overrides[get_github] = lambda: gh
    app.dependency_overrides[get_llm] = lambda: None
    app.dependency_overrides[get_session_factory] = lambda: Session
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()
    engine.dispose()


@pytest.fixture(autouse=True)
def _reset_settings():
    saved = (settings.api_key, settings.github_webhook_secret)
    yield
    settings.api_key, settings.github_webhook_secret = saved
