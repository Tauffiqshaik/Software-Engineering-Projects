"""GitHub client (against a mocked transport), LLM output validation, and the webhook."""
import hashlib
import hmac
import json

import httpx
import pytest

from app.config import settings
from app.github_client import GitHubClient, GitHubError, valid_repo
from app.llm import LLMReviewer, parse_llm_output


# ---------------------------------------------------------------- GitHub client
def make_client(handler) -> GitHubClient:
    return GitHubClient(token="tok", transport=httpx.MockTransport(handler))


def test_github_client_sends_auth_and_parses_pr():
    seen = {}

    def handler(req: httpx.Request):
        seen["auth"] = req.headers["authorization"]
        seen["path"] = req.url.path
        return httpx.Response(200, json={"title": "T", "state": "open", "head": {"sha": "deadbeef"}})

    pr = make_client(handler).get_pull_request("o/r", 5)
    assert pr == {"title": "T", "head_sha": "deadbeef", "state": "open"}
    assert seen == {"auth": "Bearer tok", "path": "/repos/o/r/pulls/5"}


def test_github_client_paginates_files():
    def handler(req: httpx.Request):
        page = int(req.url.params["page"])
        n = 100 if page == 1 else 3
        return httpx.Response(200, json=[{"filename": f"f{page}-{i}.py"} for i in range(n)])

    assert len(make_client(handler).list_pull_files("o/r", 1)) == 103


@pytest.mark.parametrize("code, expected", [(404, 404), (401, 401), (403, 403), (500, 500)])
def test_github_errors_do_not_leak_response_body(code, expected):
    def handler(req):
        return httpx.Response(code, json={"message": "secret internal detail"})

    with pytest.raises(GitHubError) as e:
        make_client(handler).get_pull_request("o/r", 1)
    assert e.value.status == expected and "secret internal detail" not in e.value.message


def test_github_network_failure_becomes_502():
    def handler(req):
        raise httpx.ConnectError("boom")

    with pytest.raises(GitHubError) as e:
        make_client(handler).get_pull_request("o/r", 1)
    assert e.value.status == 502


def test_get_file_content_handles_missing_and_binary():
    def handler(req: httpx.Request):
        if "missing" in req.url.path:
            return httpx.Response(404)
        if "bin" in req.url.path:
            return httpx.Response(200, content=b"\xff\xfe\x00")
        return httpx.Response(200, content="héllo".encode())

    c = make_client(handler)
    assert c.get_file_content("o/r", "missing.py", "sha") is None
    assert c.get_file_content("o/r", "bin.dat", "sha") is None
    assert c.get_file_content("o/r", "ok.py", "sha") == "héllo"


def test_file_path_is_url_encoded():
    seen = {}

    def handler(req: httpx.Request):
        seen["raw"] = req.url.raw_path.decode()
        return httpx.Response(200, content=b"x")

    make_client(handler).get_file_content("o/r", "dir/a b#c.py", "sha")
    assert "a%20b%23c.py" in seen["raw"]


def test_valid_repo():
    assert valid_repo("octocat/Hello-World.js")
    for bad in ["a", "a/b/c", "../x", "a/..", "a/.", "a b/c", "a/b?x=1", ""]:
        assert not valid_repo(bad), bad


# --------------------------------------------------------------- LLM validation
def test_parse_llm_output_accepts_valid_items():
    text = 'Here you go:\n[{"line": 2, "severity": "high", "category": "bug", "message": "Off by one", "suggestion": "Use <"}]'
    (issue,) = parse_llm_output(text, n_lines=5, changed_lines=None)
    assert (issue.line, issue.severity, issue.category, issue.source, issue.rule_id) == (2, "high", "bug", "llm", "LLM001")


@pytest.mark.parametrize(
    "text",
    [
        "",
        "no json here",
        "[not json]",
        '{"line": 1}',  # object, not array
        '["string", 3, null]',
        '[{"line": 99, "severity": "high", "category": "bug", "message": "x"}]',  # line out of range
        '[{"line": 0, "severity": "high", "category": "bug", "message": "x"}]',
        '[{"line": true, "severity": "high", "category": "bug", "message": "x"}]',
        '[{"line": "2", "severity": "high", "category": "bug", "message": "x"}]',
        '[{"line": 1, "severity": "critical", "category": "bug", "message": "x"}]',
        '[{"line": 1, "severity": "high", "category": "style", "message": "x"}]',
        '[{"line": 1, "severity": "high", "category": "bug", "message": ""}]',
        '[{"line": 1, "severity": "high", "category": "bug"}]',
    ],
)
def test_parse_llm_output_rejects_bad_items(text):
    assert parse_llm_output(text, n_lines=5, changed_lines=None) == []


def test_llm_findings_outside_changed_lines_dropped_and_capped():
    items = [{"line": i, "severity": "low", "category": "bug", "message": f"m{i}"} for i in range(1, 6)]
    got = parse_llm_output(json.dumps(items), n_lines=5, changed_lines={2, 3})
    assert [i.line for i in got] == [2, 3]
    many = [{"line": 1, "severity": "low", "category": "bug", "message": "m"}] * 50
    assert len(parse_llm_output(json.dumps(many), 5, None)) == 10


def test_llm_reviewer_calls_api_and_survives_failures():
    captured = {}

    def ok(req: httpx.Request):
        captured["headers"] = dict(req.headers)
        captured["body"] = json.loads(req.content)
        payload = '[{"line": 1, "severity": "medium", "category": "security", "message": "Looks risky"}]'
        return httpx.Response(200, json={"content": [{"type": "text", "text": payload}]})

    r = LLMReviewer("key-123", "model-x", transport=httpx.MockTransport(ok))
    issues = r.review("a.py", "x = 1\ny = 2\n", None)
    assert [i.message for i in issues] == ["Looks risky"]
    assert captured["headers"]["x-api-key"] == "key-123" and captured["body"]["model"] == "model-x"
    # Code is delimited and told to be treated as data (prompt-injection mitigation).
    assert "UNTRUSTED" in captured["body"]["system"]
    assert "<code>\n1: x = 1\n2: y = 2\n</code>" in captured["body"]["messages"][0]["content"]

    for failing in (
        lambda req: httpx.Response(500),
        lambda req: httpx.Response(200, text="not json"),
        lambda req: (_ for _ in ()).throw(httpx.ConnectError("down")),
    ):
        assert LLMReviewer("k", "m", transport=httpx.MockTransport(failing)).review("a.py", "x", None) == []


def test_llm_findings_are_merged_without_duplicating_static_ones(client, monkeypatch):
    from app.llm import get_llm
    from app.main import app

    class FakeLLM:
        def review(self, path, content, changed):
            from app.analyzers.base import Issue
            return [Issue("LLM001", "high", "security", 1, "dup of static", source="llm"),
                    Issue("LLM001", "medium", "bug", 2, "novel finding", source="llm")]

    app.dependency_overrides[get_llm] = lambda: FakeLLM()
    r = client.post("/reviews/snippet", json={"filename": "a.py", "code": "x = eval(a)\ny = 2\n"})
    findings = r.json()["findings"]
    assert r.json()["llm_used"] is True
    assert [(f["rule_id"], f["source"]) for f in findings] == [("PY001", "static"), ("LLM001", "llm")]
    # use_llm=false skips it
    r = client.post("/reviews/snippet", json={"filename": "a.py", "code": "x = eval(a)\ny = 2\n", "use_llm": False})
    assert r.json()["llm_used"] is False and len(r.json()["findings"]) == 1


# ---------------------------------------------------------------------- webhook
def sign(secret: str, body: bytes) -> str:
    return "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def pr_payload(action="opened", repo="octo/repo", number=3) -> bytes:
    return json.dumps({"action": action, "repository": {"full_name": repo}, "pull_request": {"number": number}}).encode()


def post_hook(client, body, secret="whsec", event="pull_request", signature="auto"):
    headers = {"X-GitHub-Event": event, "Content-Type": "application/json"}
    if signature == "auto":
        signature = sign(secret, body)
    if signature:
        headers["X-Hub-Signature-256"] = signature
    return client.post("/webhooks/github", content=body, headers=headers)


def test_webhook_rejected_when_secret_not_configured(client):
    assert post_hook(client, pr_payload()).status_code == 503


def test_webhook_rejects_bad_or_missing_signature(client):
    settings.github_webhook_secret = "whsec"
    body = pr_payload()
    assert post_hook(client, body, signature=None).status_code == 401
    assert post_hook(client, body, signature="sha256=" + "0" * 64).status_code == 401
    assert post_hook(client, body, secret="wrong-secret").status_code == 401
    assert post_hook(client, body, signature="md5=abc").status_code == 401
    # signature of a different body
    assert post_hook(client, body, signature=sign("whsec", b"other")).status_code == 401
    assert client.get("/reviews").json() == []


def test_webhook_ping_and_ignored_events(client):
    settings.github_webhook_secret = "whsec"
    assert post_hook(client, b"{}", event="ping").json() == {"status": "pong"}
    assert post_hook(client, b"{}", event="push").json() == {"status": "ignored"}
    assert post_hook(client, pr_payload(action="closed")).json() == {"status": "ignored"}
    assert post_hook(client, pr_payload(repo="../evil")).json() == {"status": "ignored"}


def test_webhook_malformed_payload(client):
    settings.github_webhook_secret = "whsec"
    assert post_hook(client, b"not json").status_code == 400
    assert post_hook(client, b'{"action": "opened"}').status_code == 400


def test_webhook_triggers_review_and_posts_comments(client, gh):
    settings.github_webhook_secret = "whsec"
    content = "password = 'hunter2hunter2'\n"
    gh.files = [{"filename": "a.py", "status": "added", "patch": "@@ -0,0 +1,1 @@\n+password = 'hunter2hunter2'"}]
    gh.contents = {"a.py": content}
    r = post_hook(client, pr_payload(number=9))
    assert r.status_code == 202 and r.json() == {"status": "queued"}
    reviews = client.get("/reviews").json()  # TestClient runs background tasks before returning
    assert len(reviews) == 1 and reviews[0]["pr_number"] == 9 and reviews[0]["counts"]["high"] == 1
    assert len(gh.posted) == 1


def test_webhook_failure_in_background_is_contained(client, gh):
    settings.github_webhook_secret = "whsec"
    gh.fail_with = GitHubError(404, "nope")
    assert post_hook(client, pr_payload()).status_code == 202
    assert client.get("/reviews").json() == []
